'use strict';
// Independently authored counterchecks, executing against an isolated, compiled copy of the original v0.10.0 sources.
const assert = require('node:assert/strict');
const {planJourneys, planDoorToDoor, parseIrishRailStationXml, createRoutingApi, fromSupabaseTables} = require('./independent_candidate/routing/dist/index.js');
const results=[];
function rec(id,data){const r={finding:id,...data};results.push(r);console.log(JSON.stringify(r));}
const date='2026-10-08';
const allDays={serviceId:'daily',startDate:'2026-10-01',endDate:'2026-10-31',weekdays:[true,true,true,true,true,true,true]};
const pos=(lat)=>({lat,lon:-9.2});
const path=(a,b,d,t)=>({distanceMeters:d,durationSeconds:t,geometry:[a,b],provider:'meta-independent'});
(async()=>{
 // A01: physically reasonable speed of 900m in 720s, rather than original fixture's 250s.
 const O=pos(54.099), A=pos(54.1), B=pos(54.105), C=pos(54.1125), D=pos(54.12), Z=pos(54.121);
 const stops=[['A',A],['B',B],['C',C],['D',D]].map(([id,p])=>({id,name:id,...p}));
 const db={feedVersion:'meta',timezone:'Europe/Dublin',stops,routes:[{id:'r1',name:'bus',mode:'bus'},{id:'r2',name:'train',mode:'rail'}],trips:[{id:'t1',routeId:'r1',serviceId:'daily'},{id:'t2',routeId:'r2',serviceId:'daily'}],stopTimes:[{tripId:'t1',stopId:'A',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'t1',stopId:'B',sequence:2,arrivalSeconds:34200,departureSeconds:34200},{tripId:'t2',stopId:'C',sequence:1,arrivalSeconds:35600,departureSeconds:35600},{tripId:'t2',stopId:'D',sequence:2,arrivalSeconds:37500,departureSeconds:37500}],calendars:[allDays],exceptions:[]};
 const req={serviceDate:date,departAfterSeconds:32400,origin:O,destination:Z,maxTransfers:1,maxWalkingMeters:2000,minTransferSeconds:120};
 const paths={origin:O,destination:Z,access:[{stopId:'A',...path(O,A,100,90)}],egress:[{stopId:'D',...path(D,Z,100,90)}],transfers:[{fromStopId:'B',toStopId:'C',...path(B,C,900,720)}]};
 const oracle=planJourneys(db,paths,req);
 let n=0;
 const pkey=(p)=>p.lat.toFixed(6)+':'+p.lon.toFixed(6);
 const requested=await planDoorToDoor(db,{walk:async(a,b)=>{
  if(pkey(a)===pkey(O)&&pkey(b)===pkey(A))return path(a,b,100,90);
  if(pkey(a)===pkey(D)&&pkey(b)===pkey(Z))return path(a,b,100,90);
  if(pkey(a)===pkey(B)&&pkey(b)===pkey(C)){n++;return path(a,b,900,720);}
  return null;
 }},req,{modes:['bus','rail'],maxRequestCount:24,maxTransferPairs:10,maxOriginStops:4,maxDestinationStops:4,maxDirectWalkMeters:0});
 assert.equal(oracle.length,1);assert.equal(requested.journeys.length,0);assert.equal(n,0);
 rec('A01',{oracleJourneys:oracle.length,plannerJourneys:requested.journeys.length,providerTransferCalls:n,walkMeters:900,walkSeconds:720,geometricDistanceApproxM:834});
 // A02: times are slower but plausible if a short accessible route takes longer due to crossing or accessibility restrictions.
 const a=pos(54.31),b=pos(54.312),dest=pos(54.313),org=pos(54.309);
 const one={feedVersion:'meta',timezone:'Europe/Dublin',stops:[{id:'a',name:'a',...a},{id:'b',name:'b',...b}],routes:[{id:'r',name:'r',mode:'bus'}],trips:[{id:'t',routeId:'r',serviceId:'daily'}],stopTimes:[{tripId:'t',stopId:'a',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'t',stopId:'b',sequence:2,arrivalSeconds:35000,departureSeconds:35000}],calendars:[allDays],exceptions:[]};
 const access=[{stopId:'a',...path(org,a,50,70)}], short={stopId:'b',...path(b,dest,120,720)}, long={stopId:'b',...path(b,dest,900,690)};
 const r2={serviceDate:date,departAfterSeconds:32400,maxTransfers:0,maxWalkingMeters:500};
 const shortOnly=planJourneys(one,{origin:org,destination:dest,access,egress:[short],transfers:[]},r2);
 const both=planJourneys(one,{origin:org,destination:dest,access,egress:[short,long],transfers:[]},r2);
 assert.equal(shortOnly.length,1);assert.equal(both.length,0);
 rec('A02',{shortOnly:shortOnly.length,both:both.length,feasibleEgressMeters:120,infeasibleEgressMeters:900,slowSeconds:720,fastSeconds:690,reachability:'accepted-array-contract; real provider returns <=1 route per stop'});
 // A03: abort while a readable request body remains open; without closing stream, response should have terminated by now.
 let close;let began=false;
 const stream=new ReadableStream({start(c){began=true;c.enqueue(new TextEncoder().encode('{'));close=()=>c.close();}});
 const controller=new AbortController();
 const handler=createRoutingApi({loadTimetable:async()=>{throw Error('should-not-reach')},router:{walk:async()=>null},consumeRateLimit:async()=>true,clientIdentity:()=> 'independent-check'});
 const request=new Request('https://example.invalid/v1/journeys',{method:'POST',headers:{'Content-Type':'application/json'},body:stream,duplex:'half',signal:controller.signal});
 let complete=false;
 const pending=handler(request).then(()=>complete=true,()=>complete=true);
 await new Promise(resolve=>setTimeout(resolve,60));controller.abort();await new Promise(resolve=>setTimeout(resolve,160));
 const afterAbort=complete;close();await pending;
 assert.equal(began,true);assert.equal(afterAbort,false);
 rec('A03',{requestSignalAborted:controller.signal.aborted,completed160msAfterAbort:afterAbort,finishedAfterExplicitStreamClose:complete});
 // A04-A05: different malformed variants than original adversarial cases.
 const xml='<ArrayOfObjStationData xmlns="http://api.irishrail.ie/realtime/"><objStationData><Traincode>Z987</Traincode><Stationfullname>Ballina</Stationfullname></objStationData></ArrayOfObjStationData>';
 const checkXml=(s)=>{let ok,err;try{const x=parseIrishRailStationXml(s,'Ballina','2026-10-09T01:00:00Z');ok=x.services.length; }catch(e){ok=false;err=e.message;}return {accepted:ok!==false,serviceCount:ok===false?0:ok,error:err}};
 const caseMismatch=xml.replace('</ArrayOfObjStationData>','</arrayofobjstationdata>');
 const qnameMismatch=xml.replace('xmlns="http://api.irishrail.ie/realtime/"','xmlns="http://api.irishrail.ie/realtime/" xmlns:z="urn:z"').replace('</ArrayOfObjStationData>','</z:ArrayOfObjStationData>');
 const malformedAttr=xml.replace('<objStationData>','<objStationData accidental=abc>');
 const duplicateAttr=xml.replace('<objStationData>','<objStationData x="1" x="2">');
 const c4=[caseMismatch,qnameMismatch].map(checkXml), c5=[malformedAttr,duplicateAttr].map(checkXml);
 assert.equal(checkXml(xml).serviceCount,1);assert(c4.every(r=>r.accepted));assert(c5.every(r=>r.accepted));
 rec('A04',{validServiceCount:1,caseMismatch:c4[0],qualifiedClosingWithoutOpening:c4[1]});
 rec('A05',{unquotedAttribute:c5[0],duplicateAttribute:c5[1]});
 // A06: standard route_type values on exactly the same adapter input.
 const rtypes=[0,2,3,4,5,999];
 const resultTypes=rtypes.map(type=>({type,observed:fromSupabaseTables({feedVersion:'m',routes:[{version:'m',route_id:'r',route_type:type}],stops:[],trips:[],stopTimes:[],calendars:[],calendarDates:[]}).routes[0].mode}));
 assert.equal(resultTypes.find(x=>x.type===4).observed,'bus');
 rec('A06',{routeModes:resultTypes});
 console.log(JSON.stringify({independentChecks:results.length,success:true}));
})().catch(err=>{console.error(err);process.exitCode=1});
