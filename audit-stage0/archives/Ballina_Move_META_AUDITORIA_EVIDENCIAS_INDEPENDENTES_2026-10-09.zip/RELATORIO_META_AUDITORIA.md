# Ballina Move — Meta-auditoria independente de reprodução

**Data:** 9 de outubro de 2026  
**Objeto:** pacote `Ballina_Move_META_AUDITORIA_PACOTE_REPRODUZIVEL_2026-10-09(1).zip`  
**Escopo:** candidato ferroviário v0.10.0 Round 3, ZIP parcial v0.9.9 e evidências da auditoria.  
**Modo:** leitura e execução offline em cópias descartáveis; nenhuma alteração de produção, GitHub, Supabase ou deploy.

## Veredito executivo

**A auditoria anterior é reproduzível para o escopo offline fornecido. Os seis comportamentos A01–A06 foram reproduzidos por verificações próprias contra cópia compilada do código original. Nenhum desses seis comportamentos foi refutado.** Isto não significa que os seis estejam ocorrendo em produção: A02 é latente/condicional ao contrato interno, A06 depende de aparecerem tipos GTFS não suportados e o impacto de A03 no Deno não foi medido. A04–A05 reproduzem aceitação de XML malformado, não uma exploração comprovada.

**Recomendação de liberação:** manter a versão ferroviária v0.10.0 bloqueada para usuários até correção e regressões, especialmente A01. **Auditoria integral do sistema:** permanece aberta, em particular para importador Python completo, banco transacional PostgreSQL, Deno e integrações externas.

## 1. Cadeia de custódia e segurança

1. Antes da execução, li `tools/replay.py` integralmente e os scripts diretamente invocados por ele: `tsc -p tsconfig.json`, testes Node de ambas as versões, verificação de paridade, `staging/tests/sealed_gate.test.cjs`, `adversarial/parte2_regressions.test.cjs`, `tests/xml_conformance.cjs` e `adversarial/reference_20000.cjs`. Examinei referências a rede, processos, escrita em disco e credenciais nos testes.
2. O replay extrai arquivos em diretórios temporários; escreve logs no diretório de resultados. `reference_20000.cjs` recebe uma substituição de **caminho de saída apenas numa cópia temporária**. Não foram encontrados comandos de deploy, commits ou escrita em Supabase nesses scripts. Os clientes de rede usados nos testes estavam simulados.
3. Os três arquivos de baseline passaram em hash SHA-256 e integridade ZIP. O ZIP de evidências original também passou em integridade. O manifesto é fornecido pelo próprio pacote, portanto as correspondências de hash garantem **consistência dos artefatos entregues**, não procedência certificada do GitHub ou assinatura independente.
4. Em cópia isolada do candidato, confrontei todos os **96 arquivos originais** com o ZIP: **96/96 idênticos em bytes** após a compilação local (o compilador gerou saídas adicionais, sem alterar o código-fonte).
5. A execução teve `PATH`, `HOME` e variáveis de ambiente controlados, sem credenciais de produção. A criação de namespace de rede via `unshare -n` foi **negada pelo ambiente**. Portanto, não alego isolamento de rede imposto pelo sistema operacional. Não foi necessário acessar serviços externos.
6. Primeira tentativa: seis falhas da suíte v0.9.9 eram erros de resolução de dependência `Cannot find module 'typescript'`; a segunda execução, com `NODE_PATH` apontando para a instalação global TypeScript 5.8.3, passou. Isso revela requisito de portabilidade do executor que deve ser explicitado. O `package.json` do candidato declara TypeScript 5.9.3: paridade da versão exata de compilação/CI não foi provada.

**SHA-256 candidato v0.10.0:** `94b52715e4842d73cdf9a48e23c75815bd3fccd4756bc4796e1f438ee1ffa7a2`  
**SHA-256 pacote parcial v0.9.9:** `f994fb99f556c62a4ee785fd32656c712f9d71ea7c95818668f5f656c6eb3ebd`  
**SHA-256 auditoria adversarial PARTE 2:** `6e77f272f3aabdbdf73c6f2d7f299b30148b9a80f534d74776959586e26e7fc6`.

## 2. Resultados do replay

| Ensaio | Resultado próprio | Interpretação |
|---|---:|---|
| Build TypeScript v0.9.9 parcial | OK | Compilação sob TS 5.8.3 |
| Testes v0.9.9 parcial | 204/204 | Só da cópia parcial |
| Build TypeScript v0.10.0 | OK | Compilação sob TS 5.8.3 |
| Testes v0.10.0 | 245/245 | Aprovação da suíte interna |
| Paridade de artefato | 16/16 | Igualdade de tokens com compilado local; não prova equivalência operacional |
| Staging selado | 6/6 | Staging não executa rotas no cenário testado |
| Regressões adversariais | 3 controles aprovados, 5 falhas esperadas | Falhas reproduzidas com seus nomes corretos |
| Corpus XML | 11 casos, 6 XML inválidos aceitos; 2 XML válidos rejeitados | Aceitação inválida confirma A04/A05; rejeições válidas podem ser restrições deliberadas |
| Referência simplificada | 20.000 casos, 19.283 elegíveis, 0 divergências | Apenas melhor ETA sem baldeações a pé |
| Contra-provas próprias | 6/6 achados reproduzidos | Código independente de teste, fonte original |

Nota: a verificação `RESULT: PASS` do executor significa que os resultados **esperados por seus próprios critérios** ocorreram, incluindo retorno 1 da suíte adversarial. Ela não é um atestado de correção do software.

## 3. Matriz de veredito A01–A06

| ID | Classificação pedida | Evidência própria | Interpretação e alcance |
|---|---|---|---|
| **A01** | **CONFIRMADO INDEPENDENTEMENTE** | Código `planner.ts:188` e `pedestrian.ts:189` aplica corte geométrico de 650 m. Contraexemplo independente: caminhada **900 m em 720 s** (velocidade plausível, ~1,25 m/s), conexão separada ~834 m em linha reta, limite de caminhada 2.000 m: `planJourneys` recebe trajetos completos e retorna **1**, `planDoorToDoor` retorna **0** e realiza **0** solicitações para a transferência. | Falha real de descoberta com falsa negativa no produto que promete considerar rotas compatíveis com orçamento; pode ser atenuada se limites incompletos forem explicitamente comunicados. **Alta**, pela possível supressão de itinerário viável. O `planJourneys` não é um oráculo externo; a consistência foi adicionalmente checada por horário e orçamento de caminhada. |
| **A02** | **CONFIRMADO INDEPENDENTEMENTE (LATENTE)** | `engine.ts:198–204` guarda o menor tempo de saída por parada antes de aplicar a capacidade de caminhada. Duas opções para mesma parada: 120 m / 720 s e 900 m / 690 s, limite 500 m: com a primeira, **1** itinerário; com ambas, **0**. | Viola a propriedade monotônica de adicionar uma opção e perder uma opção válida dentro do contrato `PedestrianPaths`. **Não foi demonstrado no fluxo normal**, que normalmente produz uma saída por parada; prioridade operacional pode ser menor. Tempos são sintéticos, e a condição de duplicatas é essencial. |
| **A03** | **CONFIRMADO INDEPENDENTEMENTE EM NODE** | `httpApi.ts:79–96`: `await reader.read()` não reage explicitamente a `req.signal`. Um corpo parcialmente enviado e ainda aberto: após abortar, a promessa **permanece pendente 160 ms**; só resolve ao fechar manualmente o stream. | Evidência local concreta de ausência de resposta ao aborto. **Comportamento sob Deno Edge, liberação de memória e possibilidade de exploração em produção permanecem inconclusivos**. Não confundir tempo observado com prova de espera ilimitada em toda implementação. |
| **A04** | **CONFIRMADO INDEPENDENTEMENTE** | `irishRail.ts:96–103`: comparação case-insensitive na raiz e prefixos não vinculados. XML com raiz fechada usando case diferente ou QName prefixado apenas no fechamento retorna serviço válido. | Rejeição é exigida pelas regras de boa formação XML. Impacto real depende de fonte externa e do uso do dado. Não foi demonstrada exploração. |
| **A05** | **CONFIRMADO INDEPENDENTEMENTE** | `irishRail.ts:61–90`: expressões regulares aceitam atributos livres. Variantes com atributo sem aspas e atributo duplicado retornam um serviço. XML de referência rejeita ambos. | Violação sintática concreta do XML. Gravidade operacional e implicações de segurança devem ser avaliadas separadamente; não há demonstração de injeção nem XXE. |
| **A06** | **CONFIRMADO INDEPENDENTEMENTE (CONDICIONAL)** | `supabaseAdapter.ts:22`: `route_type===2 ? 'rail' : 'bus'`. Entradas `0, 4, 5, 999` são todas convertidas para `bus`; `2` → `rail` e `3` → `bus`. A especificação GTFS define **4 = ferry**. | Erro de classificação para outros modais, reproduzido em entrada válida `4`. **Não verifiquei a composição do feed ativo nesta execução**; a alegação de ausência de balsas em Mayo vem do relatório anterior. |

**Contagem na matriz:** 6 confirmados para os comportamentos testados; **0 contestados, 0 falsos positivos e 0 inconclusivos quanto à reprodução local**. Várias alegações *adicionais* de alcance e impacto operacional permanecem inconclusivas, conforme a coluna final.

## 4. Crítica dos oráculos

- **A01:** o teste anterior usava 900 m em 250 s, correspondente a 3,6 m/s, não uma caminhada típica. Fiz uma nova reprodução com 900 m em 720 s, fisicamente plausível. Uma checagem manual das horas confirma o encadeamento: chegada ao ponto de transferência 09:30, caminhada de 12 min até 09:42, partida seguinte 09:53:20, margem superior a 2 min; caminhada total 1.100 m dentro de 2 km. As propriedades de validade de ligação e tempo devem ser confrontadas com GTFS real antes de declarar impacto específico em Mayo.
- **A02:** o oráculo original testa múltiplas alternativas de saída para a mesma parada, enquanto o produtor integrado normalmente entrega uma. Portanto demonstra um **defeito do contrato aceito pelo motor**, não incidência atual. A saída curta do teste independente é lenta; serve para confrontar a regra tempo×distância, não como previsão de pedestrianismo real.
- **A03:** o teste identifica uma falha de cancelamento na interface Request/ReadableStream em Node. Um mock pode divergir da implementação de streams e limites de duração do Supabase/Deno. Falta execução real nesse ambiente, sem envolver serviços de produção.
- **A04/A05:** Python `xml.etree.ElementTree` é um oráculo independente de *boa formação* XML, não prova compatibilidade completa com o subconjunto de formatos aceitos pelo provedor. As seis aceitações malformadas são válidas como divergências estruturais; as duas rejeições de XML bem formado **não são automaticamente defeitos**, por restrições do contrato do provedor.
- **A06:** comparei a saída com a especificação oficial GTFS `routes.txt`. Classificar modais ainda não suportados como ônibus pode ser escolha de fallback, mas produz semântica falsa, não uma implementação legítima de ferry.
- **Comparador de 20.000 redes:** compara apenas o melhor ETA em redes pequenas de cinco paradas, sem transferência a pé, mudanças de DST, trajetos multimodais complexos nem análise da fronteira de Pareto. Logo, **não refuta A01/A02 nem prova completude geral**. A geração usa `Array.sort(() => rand() - 0.5)`, uma forma de embaralhamento com comparador não transitivo, que também enfraquece consistência da distribuição entre runtimes.
- **Contagem dos testes:** `replay.py` verifica padrões de contagem e resultados, mas não impõe que cada falha tenha uma determinada identidade; confrontei também **os nomes** das cinco falhas no TAP. Reexecutar um teste não torna automaticamente o oráculo independente.

## 5. Limitações e qualidade final da evidência

**Pontos fortes:** baselines integradas no pacote, SHA de ZIPs, logs integrais, arquivos de testes originais, runner documentado, controles positivos, corpus XML com validador separado e possibilidade real de replay. A meta-auditoria acrescenta contraexemplos próprios e comparação de fontes originais 96/96. A crítica da rodada anterior sobre falta dos ZIPs foi resolvida para o **candidato offline**.

**Pontos fracos ainda impeditivos:**

1. O ZIP v0.9.9 é **parcial** e não certifica o commit inteiro do GitHub; a v0.10.0 está fora da main e seu checksum não tem atestação pública independente.
2. Ausência de Deno Edge real, PostgreSQL descartável, teste integral de importador Python, feeds RT de ponta a ponta e métricas operacionais.
3. Runtime TypeScript local 5.8.3, enquanto a dependência declarada é 5.9.3; instalação local precisa de descoberta de módulo ou `NODE_PATH` para que os testes executem sem `npm ci`.
4. Sem namespace de rede no container; o ambiente foi sanitizado e os testes são mockados, mas **não houve bloqueio de rede no nível do kernel**.
5. A01 não possui limite e cobertura de busca formais validados para o produto; sem especificação do que deve ser completo sob custos limitados, o contrato permanece parcialmente ambíguo.

**Veredito sobre as evidências:** **APROVADAS COM RESSALVAS PARA REPRODUÇÃO OFFLINE**, não certificação de toda a arquitetura.  
**Veredito sobre o candidato ferroviário:** **NÃO APTO PARA PUBLICAÇÃO**, devido a A01 e às integrações críticas não verificadas.  
**Confiança:** alta sobre os seis comportamentos reproduzidos, média sobre sua prevalência e gravidade em tráfego real.

## 6. Arquivos de suporte

- `results/RESULTS.json`: execução do runner e hashes.
- `results/adversarial_replay.log`: nomes dos testes negativos.
- `results/xml_corpus.log`: divergências XML com validador Python.
- `results/reference_20000.log`: comparador simplificado.
- `results/independent_checks.log`: seis contraexemplos próprios em execução.
- `results/source_hash_check.json`: 96/96 fontes inalteradas.
- `independent_checks.cjs`: código dos contraexemplos próprios.
- `results/verify_only.log`: integridade dos baselines.

**Fontes normativas:** [GTFS Schedule Reference](https://gtfs.org/documentation/schedule/reference/) e [W3C XML 1.0](https://www.w3.org/TR/xml/).
