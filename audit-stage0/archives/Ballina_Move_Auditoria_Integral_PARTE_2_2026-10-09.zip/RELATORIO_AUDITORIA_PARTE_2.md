# Ballina Move — Auditoria integral, parte 2 de 2: ataques independentes

**Data:** 2026-10-09  
**Objeto auditado:** `Ballina_Move_v0.10.0_AUDITORIA_RODADA3_COMPLETO.zip`  
**SHA-256 do original:** `94b52715e4842d73cdf9a48e23c75815bd3fccd4756bc4796e1f438ee1ffa7a2`  
**Status:** diagnóstico e reprodução, **SEM correções no código original**, nenhuma publicação, nenhum contato com Stadia nem Irish Rail.  
**Conceito de auditoria integral:** inventário completo na parte 1, ataques orientados por risco na parte 2. Não significa prova formal de todas as execuções ou validação operacional em produção.

## A. Veredito

**Não liberar a v0.10.0 para passageiros ainda.** Foram reproduzidos **quatro tipos de defeito** ainda presentes no pacote congelado (o caso de XML possui dois subcasos), com testes de controle. Um quinto risco futuro, a classificação de modal GTFS não suportado, foi demonstrado, mas **não se manifesta no feed ativo conhecido**, que contém apenas `route_type=2/3`.

O caso mais importante é a falta de completude na descoberta de transferências: o motor é capaz de calcular um trajeto cuja caminhada entre paradas é fornecida, mas `planDoorToDoor` **não tenta pedir** a caminhada porque a distância em linha reta supera 650 m. O orçamento do passageiro era 2.000 m. Não há indicação de busca incompleta na resposta da fixture.

## B. Baseline e método

- A integridade e o SHA-256 do arquivo foram conferidos antes de extraí-lo numa pasta separada.
- Compilação com `tsc` local **5.8.3**, não a dependência fixada 5.9.3; o runtime Deno está ausente neste ambiente. `245/245` testes originais aprovados.
- **20.000 grafos sintéticos gerados por sementes reproduzíveis**, com 12 viagens, até 5 paradas e até 2 baldeações, confrontados com enumerador independente das possibilidades de embarque. **19.283 cenários tinham itinerário possível; zero divergências na melhor chegada** dentro desse modelo restrito (sem transferências a pé entre paradas, sem alternativas de acesso/saída, sem dias consecutivos ou alteração DST). Isso valida um subconjunto, não todo o algoritmo.
- **8 testes adversariais independentes:** três controles passaram; cinco testes falharam, correspondentes a quatro categorias de problemas.
- Stress do cliente Irish Rail: **64 chamadas simultâneas à mesma estação resultaram em uma chamada HTTP simulada**. Depois de primeira resposta 503, a próxima chamada teve sucesso (sem cache de falha).
- Snapshot do GTFS: a fixture com feed estável carregou; a alteração da versão ativa durante o carregamento gerou `active_feed_switched_during_snapshot` como esperado.
- Sem testes reais de CPU, RSS em produção, cold start, Deno runtime, rede real nem provider paid.

## C. Defeitos reproduzidos

### P2-01 — Transferência de 650–2.000 metros nunca descoberta (ALTA: itinerário perdido)

**Código:** `routing/src/planner.ts:188` e `routing/src/pedestrian.ts:189`, ambos com limite absoluto de 650 m.  
**Entrada:** duas viagens (`T1` ônibus A→B e `T2` trem C→D), conexão B→C com cerca de 834 m de separação; o roteador de teste oferece uma caminhada de 900 m, 250 s; `maxWalkingMeters=2000`, buffer de embarque satisfeito.  
**Esperado:** ao menos uma jornada ônibus+caminhada+trem, já que a própria `planJourneys` retorna uma quando a caminhada é fornecida.  
**Observado:** `planDoorToDoor` devolve 0 jornadas e jamais chama `router.walk(B,C)`, ainda que `coverage.candidateLimitReached=false`.  
**Controle:** a mesma fixture com separação de aproximadamente 500 m devolve uma jornada e consulta o roteador.  
**Risco de regressão:** ampliar indiscriminadamente o raio pode produzir O(n²) pares e consumir chamadas pagas. A correção precisa de um algoritmo de seleção por orçamento e cobertura, e métricas de busca incompleta; não é apenas substituir 650 por 2000.

### P2-02 — Escolha de saída por menor duração descarta opção dentro do limite de caminhada (MÉDIA, LATENTE na integração atual)

**Código:** `routing/src/engine.ts:198–204`, antes de aplicar `walkingCap` em `routing/src/engine.ts:297–300`.  
**Entrada:** mesmo stopId de desembarque com dois caminhos alternativos para o destino: 10 s/900 m e 80 s/100 m; limite do usuário 500 m.  
**Esperado:** usar o caminho de 80 s/100 m.  
**Observado:** o código guarda exclusivamente a saída de 10 s/900 m e retorna zero jornadas.  
**Controle:** retirando o caminho de 900 m, a jornada é encontrada.  
**Nota de alcance:** o construtor de caminhada atual normalmente gera somente uma saída por parada. A falha está no contrato `PedestrianPaths`, quando integrações futuras fornecerem alternativas. Não atribuir impacto atual sem comprovação no produtor real.  
**Risco de regressão:** manter muitas saídas por stopId amplia estados; filtrar primeiro pelo limite e preservar Pareto duração/distância de forma limitada.

### P2-03 — Parser aceita raiz XML com fechamento incompatível (BAIXA-MÉDIA: validação indevida)

**Código:** `routing/src/irishRail.ts:96–101`. A regex de fechamento é case-insensitive e não vincula o prefixo da raiz de abertura ao de fechamento.  
**Entrada 1:** `<ArrayOfObjStationData>... </arrayofobjstationdata>`.  
**Entrada 2:** `<x:ArrayOfObjStationData>... </y:ArrayOfObjStationData>`.  
**Esperado:** rejeitar ambos como XML não bem formado; XML exige nomes correspondentes e diferencia maiúsculas/minúsculas.  
**Observado:** ambos são aceitos e produzem 1 serviço de trem.  
**Controle:** a raiz com fechamento idêntico é aceita corretamente.  
**Risco de regressão:** preservação dos namespaces oficiais da Irish Rail. Idealmente usar parser XML restrito, sem DTDs/entidades externas, ou checagem explícita do QName de abertura e fechamento.

### P2-04 — Leitura de JSON fica pendente após abort da requisição (MÉDIA: risco de recursos)

**Código:** `routing/src/httpApi.ts:79–96`; `reader.read()` em laço sem listener para `req.signal` e sem prazo absoluto.  
**Entrada:** POST com `Content-Type: application/json`, `ReadableStream` que envia `{` e não encerra; o cliente aborta a requisição; rate-limit mock habilitado.  
**Esperado:** liberar o leitor/rejeitar prontamente quando o sinal é abortado.  
**Observado:** a Promise continua pendente 150 ms depois do abort; só finaliza ao encerrar manualmente o stream, retornando 400.  
**Risco de regressão:** é necessário cancelar leitura e impor limite de prazo usando sinal do servidor, sem quebrar uploads normais; a plataforma real pode impor limites adicionais que não foram medidos. Não confundir este teste de comportamento do handler com prova de DoS em produção.

## D. Defeito condicional adicional (não ativo no feed atual conhecido)

**P2-05 — `route_type=4` do GTFS vira `mode='bus'`**, em `routing/src/supabaseAdapter.ts:22` (ternário `route_type===2?'rail':'bus'`). Tipo 4 significa balsa no GTFS. Fixture controlada demonstrou classificação como ônibus. O feed ativo já examinado contém apenas tipos 2 e 3; logo é um problema de extensibilidade e validação futura, não uma falha atual das rotas de Mayo. Deve falhar fechado ou oferecer suporte explícito aos outros modais, em vez de alterar silenciosamente o significado.

## E. Controles que resistiram a testes novos

| Área | Verificação | Resultado |
|---|---|---|
| Embarque/horários em redes pequenas | 20 mil redes; 19.283 viáveis, até dois transbordos, melhor chegada contra enumerador | **0 divergências** no subconjunto testado |
| Cache Irish Rail | 64 consultas simultâneas de mesma estação | **1 chamada mock** |
| Cache após erro | 503 seguida de 200 | recupera corretamente |
| GTFS snapshot | troca do feed ativo antes da segunda verificação | rejeita snapshot misto |
| Staging/CI local | Baseline tsc + testes originais | **245/245** |
| Infra real | Nenhuma interação de escrita | preservada; não houve deploy |

## F. Reavaliação dos 12 riscos da primeira metade

| Risco | Estado após segunda metade |
|---|---|
| R-01: Pareto e margem de baldeação | **Decisão de produto em aberto**: margem não integra a função de dominância. Não declarar bug sem regra funcional desejada; risco de preferir ligação apertada continua. |
| R-02: busca aproximada, limites de estados, candidatos | **P2-01 confirmado** no raio fixo; 20 mil redes básicas resistiram, mas não testam estados de alta cardinalidade e caminhos com muitos trade-offs. |
| R-03: buffer 180 s universal | **Risco operacional não resolvido**: testado como regra programada, não como garantia de conexão. |
| R-04: `route_type` diferente de ônibus/trem | **P2-05 demonstrado condicionalmente**. |
| R-05: parser XML | **P2-03 confirmado**; outras entradas reais ainda não examinadas. |
| R-06: timeout fornecedor | Cache/timeout existente resistiu nos testes do projeto; não houve teste real com tráfego Irish Rail. |
| R-07: DST | **Limitação deliberada**: datas de mudança de horário são rejeitadas, não traduzidas. |
| R-08: cancelamentos/atrasos | **Funcionalidade ainda ausente no planejador**; painel da estação não equivale a itinerário real-time. |
| R-09: gateway privado | Sem novo bypass demonstrado. WebApp depende de servidor/proxy, não deve embutir segredo no navegador. |
| R-10: CI e Deno | **Não verificado**: Deno ausente; TypeScript local 5.8.3, projeto declara 5.9.3; depende de CI remota. |
| R-11: leitores/corpos lentos | **P2-04 confirmado** para JSON de entrada; caminhada usa abort em outro caminho. |
| R-12: paginação/feed | **Controle passou**: troca de feed detectada; não equivale a benchmark sob carga real. |

## G. Plano de correção recomendado (fora desta auditoria)

1. **P2-01**: projeto de descoberta por orçamento, raio configurável por modo, limites de cobrança/cpu, indicador de cobertura; testar com caminhada autorizada de 500/834/1500 m e cenários de muitas paradas. Sem gerar chamadas pagas até autorização.
2. **P2-04**: deadline e cancelamento de corpo HTTP, incluindo `req.signal`; teste de stream lento que aborta e libera o leitor.
3. **P2-03**: checagem estrita de nome da raiz e namespaces; corpus de XML válido da Irish Rail antes de liberar o painel.
4. **P2-02**: filtragem pelo orçamento antes da escolha de egress e preservação limitada de alternativas de duração/distância.
5. **P2-05**: tratar tipos GTFS desconhecidos explicitamente; não converter ferry/tram para ônibus silenciosamente.
6. Decidir regra de confiabilidade ferroviária (transbordos apertados, cancelamentos) e só então alterar Pareto.
7. Compilar com TypeScript 5.9.3 na CI, exercitar Deno no staging privado e medir CPU/RAM/cold start sob dados reais sem Stadia antes de disponibilizar itinerários.

## H. Como reproduzir

O pacote de evidências acompanha:

- `adversarial/parte2_regressions.test.cjs`: 8 testes; baseline esperado **3 OK / 5 FAIL** (os testes falhando são provas contra a versão congelada; não são testes "quebrados" a apagar).
- `adversarial/reference_vs_engine.cjs`, `adversarial/reference_20000.cjs`: busca exaustiva de referência e gerador com seeds determinísticas.
- `adversarial/targeted_counterexamples.cjs`: contadores de casos P2-01/02/03.
- `adversarial/slow_body.cjs`: diagnóstico P2-04.
- `adversarial/data_and_cache_checks.cjs`: deduplicação/cache e tipo GTFS 4.
- `adversarial/snapshot_version_switch.cjs`: controle de feed misto.
- `logs/`: saída da suíte original e das baterias independentes.

Instruções de reprodução, a partir da raiz do projeto v0.10.0 extraído (com `routing` ao lado da pasta da auditoria): `cd routing && tsc -p tsconfig.json && node --test ../auditoria-parte2/adversarial/parte2_regressions.test.cjs`. Ajuste a estrutura relativa conforme o ZIP: os scripts estão preparados para exigir `../source/routing/dist/index.js` quando executados dentro desta pasta de auditoria. Não instale dependências não verificadas nem divulgue credenciais.

## I. Limites e decisão final

**Esta segunda metade conclui os ataques offline selecionados, não uma prova formal da ausência de outros bugs.** Não medimos uso real de CPU, Deno, tempo de inicialização fria, comportamento sob tráfego da Irish Rail, dispositivos móveis, 10 mil clientes ou qualidade de calçadas. Os falsos positivos devem ser descartados com controles, e todos os achados P2-01..P2-04 precisam ser corrigidos e retestados antes de promover a v0.10.0 para staging funcional.

**Não foi alterado o código do motor, nenhum teste original foi apagado, nenhum deploy/commit/banco foi modificado.**
