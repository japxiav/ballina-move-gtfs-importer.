# Como usar a auditoria parte 2

1. Leia `RELATORIO_AUDITORIA_PARTE_2.md`.
2. Mantenha a versão original `Ballina_Move_v0.10.0_AUDITORIA_RODADA3_COMPLETO.zip` como base congelada (SHA-256 no relatório).
3. Para reproduzir diretamente os testes deste pacote, extraia o ZIP original na pasta `source` ao lado de `adversarial` e execute, dentro de `source/routing`, `tsc -p tsconfig.json` e, depois, `node --test ../../adversarial/parte2_regressions.test.cjs`.
4. Resultado esperado antes das correções: **8 testes, 3 controles aprovados, 5 testes adversariais falhos.** Esses cinco devem ficar verdes após corrigir as quatro categorias de defeito.
5. Rode `node ../../adversarial/reference_20000.cjs` para os 20 mil casos de referência.
6. Não envie estas fixtures para produção e não use chaves reais.
