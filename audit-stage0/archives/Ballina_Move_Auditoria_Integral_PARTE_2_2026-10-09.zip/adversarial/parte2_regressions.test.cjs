'use strict';
// Independent adversarial spec. Run on frozen v0.10.0 Round 3. Expected: 4 failures.
const assert=require('node:assert/strict');
const test=require('node:test');
const {planJourneys,planDoorToDoor,parseIrishRailStationXml,createRoutingApi}=require('../source/routing/dist/index.js');
const C=lat=>({lat,lon:-9.2}), P=(a,b,s,m)=>({durationSeconds:s,distanceMeters:m,geometry:[a,b],provider:'offline-audit-fixture'});
const WEEK={serviceId:'WK',startDate:'2026-10-01',endDate:'2026-10-31',weekdays:[true,true,true,true,true,true,true]};
const REQUEST={serviceDate:'2026-10-08',departAfterSeconds:32400,maxTransfers:0,maxWalkingMeters:500};
function singleRide(){const A=C(54.1),B=C(54.101),O=C(54.099),D=C(54.102);return {A,B,O,D,db:{feedVersion:'independent',timezone:'Europe/Dublin',stops:[{id:'A',name:'A',...A},{id:'B',name:'B',...B}],routes:[{id:'R',name:'R',mode:'rail'}],trips:[{id:'T',routeId:'R',serviceId:'WK'}],stopTimes:[{tripId:'T',stopId:'A',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'T',stopId:'B',sequence:2,arrivalSeconds:36000,departureSeconds:36000}],calendars:[WEEK],exceptions:[]}}}
function egressFixture(){const {A,B,O,D,db}=singleRide();const access={stopId:'A',...P(O,A,0,0)};return {db,walk:{origin:O,destination:D,access:[access],egress:[{stopId:'B',...P(B,D,10,900)},{stopId:'B',...P(B,D,80,100)}],transfers:[]}}}
test('CONTROL 1: one slower low-distance egress produces itinerary',()=>{const {db,walk}=egressFixture();assert.equal(planJourneys(db,{...walk,egress:[walk.egress[1]]},REQUEST).length,1)});
test('FINDING 1: adding an infeasible fast egress must not delete a feasible trip',()=>{const {db,walk}=egressFixture();assert.equal(planJourneys(db,walk,REQUEST).length,1)});
async function transferCase(gap){const p={O:C(54.099),A:C(54.1),B:C(54.105),C:C(54.105+gap),D:C(54.113),Z:C(54.114)};const d={feedVersion:'independent',timezone:'Europe/Dublin',stops:['A','B','C','D'].map(id=>({id,name:id,...p[id]})),routes:[{id:'R1',name:'R1',mode:'bus'},{id:'R2',name:'R2',mode:'rail'}],trips:[{id:'T1',routeId:'R1',serviceId:'WK'},{id:'T2',routeId:'R2',serviceId:'WK'}],stopTimes:[{tripId:'T1',stopId:'A',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'T1',stopId:'B',sequence:2,arrivalSeconds:34200,departureSeconds:34200},{tripId:'T2',stopId:'C',sequence:1,arrivalSeconds:35600,departureSeconds:35600},{tripId:'T2',stopId:'D',sequence:2,arrivalSeconds:37500,departureSeconds:37500}],calendars:[WEEK],exceptions:[]};let transferCalls=0;
const eq=(a,b)=>a.lat===b.lat&&a.lon===b.lon;
const router={walk:async(a,b)=>{if(eq(a,p.O)&&eq(b,p.A))return P(a,b,0,0);if(eq(a,p.D)&&eq(b,p.Z))return P(a,b,0,0);if(eq(a,p.B)&&eq(b,p.C)){transferCalls++;return P(a,b,250,900);}return null;}};
const opts={modes:['bus','rail'],maxRequestCount:24,maxOriginStops:4,maxDestinationStops:4,maxTransferPairs:10,maxDirectWalkMeters:0};const req={serviceDate:'2026-10-08',departAfterSeconds:32400,maxTransfers:1,maxWalkingMeters:2000,origin:p.O,destination:p.Z};
const plan=await planDoorToDoor(d,router,req,opts);
const fullPaths={origin:p.O,destination:p.Z,access:[{stopId:'A',...P(p.O,p.A,0,0)}],egress:[{stopId:'D',...P(p.D,p.Z,0,0)}],transfers:[{fromStopId:'B',toStopId:'C',...P(p.B,p.C,250,900)}]};
const engine=planJourneys(d,fullPaths,req);
return {plan:plan.journeys.length,reference:engine.length,transferCalls,coverage:plan.coverage};}
test('CONTROL 2: a verified transfer 500m apart is discovered',async()=>{const x=await transferCase(.0045);assert.equal(x.reference,1);assert.equal(x.plan,1);assert.ok(x.transferCalls>0)});
test('FINDING 2: an 834m verified transfer with 2000m budget must be considered',async()=>{const x=await transferCase(.0075);assert.equal(x.reference,1);assert.equal(x.plan,1)});
const valid='<ArrayOfObjStationData><objStationData><Traincode>A123</Traincode><Stationfullname>Ballina</Stationfullname></objStationData></ArrayOfObjStationData>';
const rootCase=valid.replace('</ArrayOfObjStationData>','</arrayofobjstationdata>');
const prefixCase=valid.replace('<ArrayOfObjStationData>','<x:ArrayOfObjStationData>').replace('</ArrayOfObjStationData>','</y:ArrayOfObjStationData>');
const parser=x=>parseIrishRailStationXml(x,'Ballina','2026-10-08T09:00:00Z');
test('CONTROL 3: well-formed Irish Rail XML parses one train',()=>{assert.equal(parser(valid).services.length,1)});
test('FINDING 3A: XML closing root tag is case-sensitive',()=>{assert.throws(()=>parser(rootCase),/invalid_rail_xml_response/)});
test('FINDING 3B: XML root opening/closing namespace prefixes must match',()=>{assert.throws(()=>parser(prefixCase),/invalid_rail_xml_response/)});
async function hangingApi(){let end;const body=new ReadableStream({start(c){end=()=>c.close();c.enqueue(new TextEncoder().encode('{'))}});const controller=new AbortController();const req=new Request('https://example.invalid/v1/journeys',{method:'POST',headers:{'Content-Type':'application/json'},body,duplex:'half',signal:controller.signal});const handler=createRoutingApi({loadTimetable:async()=>{throw Error('not-called')},router:{walk:async()=>null},consumeRateLimit:async()=>true,clientIdentity:()=> 'offline-test'});let settled=false;const processing=handler(req).then(r=>{settled=true;return r.status}).catch(e=>{settled=true;return e.name});await new Promise(r=>setTimeout(r,50));controller.abort();await new Promise(r=>setTimeout(r,80));const afterAbort=settled;end();await processing;return afterAbort;}
test('FINDING 4: aborted client request must terminate waiting for its JSON body',async()=>{assert.equal(await hangingApi(),true)});
