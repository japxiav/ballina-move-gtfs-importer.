'use strict';
const {createRoutingApi}=require('../source/routing/dist/index.js');
let release;const stream=new ReadableStream({start(c){release=()=>c.close();c.enqueue(new TextEncoder().encode('{'));}});
const abort=new AbortController();
const deps={loadTimetable:async()=>{throw Error('should_not_call')},router:{walk:async()=>null},clientIdentity:()=> 'offline',consumeRateLimit:async()=>true,now:()=>new Date('2026-10-08T12:00:00Z')};
const handler=createRoutingApi(deps);
const req=new Request('https://example.invalid/v1/journeys',{method:'POST',headers:{'Content-Type':'application/json'},body:stream,duplex:'half',signal:abort.signal});
let settled=false;const start=Date.now();const work=handler(req).then(x=>{settled=true;return x.status}).catch(x=>{settled=true;return x.message});
(async()=>{await new Promise(r=>setTimeout(r,150));const stillWaitingBeforeAbort=!settled;abort.abort('client-disconnected');await new Promise(r=>setTimeout(r,150));const stillWaitingAfterAbort=!settled;release();const completion=await Promise.race([work,new Promise(r=>setTimeout(()=>r('timed_out_after_manual_close'),1000))]);console.log(JSON.stringify({stillWaitingBeforeAbort,stillWaitingAfterAbort,completion,observedMs:Date.now()-start,timeoutAppliedToBody:false}));})().catch(e=>console.error(e));
