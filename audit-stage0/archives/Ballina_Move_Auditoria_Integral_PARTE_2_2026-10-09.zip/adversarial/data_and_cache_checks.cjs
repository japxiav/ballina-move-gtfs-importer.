const {fromSupabaseTables,createIrishRailStationClient,loadActiveGtfsSnapshot}=require('../source/routing/dist/index.js');
const xml='<ArrayOfObjStationData><objStationData><Traincode>A123</Traincode><Stationfullname>Ballina</Stationfullname><Schdepart>09:10</Schdepart></objStationData></ArrayOfObjStationData>';
async function main(){
 let requests=0;
 const client=createIrishRailStationClient({fetcher:async()=>{requests++;await new Promise(r=>setTimeout(r,30));return new Response(xml,{status:200,headers:{'Content-Type':'text/xml'}})},now:()=>new Date('2026-10-09T00:00:00Z')});
 const boards=await Promise.all(Array.from({length:64},()=>client('Ballina')));
 console.log('CACHE 64 concurrent:',JSON.stringify({requests,boards:boards.length,all1Service:boards.every(x=>x.services.length===1)}));
 let tries=0;const retry=createIrishRailStationClient({fetcher:async()=>{tries++;return new Response(xml,{status:tries===1?503:200})}});
 let failed=false;try{await retry('Ballina')}catch{failed=true};let recovered=await retry('Ballina');console.log('CACHE failure recovered:',JSON.stringify({tries,firstFailed:failed,secondOk:recovered.services.length===1}));
 const version='v';const tables={feedVersion:version,stops:[{version,stop_id:'X',stop_name:'Port',stop_lat:54.1,stop_lon:-9.2}],routes:[{version,route_id:'F',route_short_name:'F',route_type:4}],trips:[],stopTimes:[],calendars:[],calendarDates:[]};
 const mapped=fromSupabaseTables(tables);
 console.log('GTFS unsupported route type:',JSON.stringify({inputRouteType:4,producedMode:mapped.routes[0].mode,expectedSemantics:'ferry/unsupported, not bus'}));
}
main().catch(e=>{console.error(e);process.exitCode=1});
