'use strict';
const {planJourneys,planDoorToDoor,parseIrishRailStationXml,fromSupabaseTables}=require('../source/routing/dist/index.js');
const DT='2026-10-08', t0=32400;const C=(lat)=>({lat,lon:-9.2});
const geo=(a,b)=>[a,b];const makePath=(a,b,duration,distance)=>({durationSeconds:duration,distanceMeters:distance,geometry:geo(a,b),provider:'offline-test-only'});
const week={serviceId:'S',startDate:'2026-10-01',endDate:'2026-10-31',weekdays:[true,true,true,true,true,true,true]};
const O=C(54.099),D=C(54.110),A=C(54.100),B=C(54.101);
const base={feedVersion:'audit-fixture',timezone:'Europe/Dublin',stops:[{id:'A',name:'A',...A},{id:'B',name:'B',...B}],routes:[{id:'R',name:'R',mode:'bus'}],trips:[{id:'T',routeId:'R',serviceId:'S'}],stopTimes:[{tripId:'T',stopId:'A',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'T',stopId:'B',sequence:2,arrivalSeconds:36000,departureSeconds:36000}],calendars:[week],exceptions:[]};
const req={serviceDate:DT,departAfterSeconds:t0,maxTransfers:0,maxWalkingMeters:500};
const p={origin:O,destination:D,access:[{stopId:'A',...makePath(O,A,0,0)}],egress:[{stopId:'B',...makePath(B,D,10,900)},{stopId:'B',...makePath(B,D,80,100)}],transfers:[]};
const result=planJourneys(base,p,req);const control=planJourneys(base,{...p,egress:[p.egress[1]]},req);
console.log('CASE-01 short-fast-egress-vs-walk-budget',JSON.stringify({withBoth:result.length,withShortOnly:control.length,expectedArrival:control[0]?.arrivalAtSeconds}));
async function transferCase(gap){
 const co={O:C(54.099),A:C(54.1),B:C(54.105),C:C(54.105+gap),D:C(54.113),Z:C(54.114)};
 const data={feedVersion:'audit-transfers',timezone:'Europe/Dublin',stops:['A','B','C','D'].map(id=>({id,name:id,...co[id]})),routes:[{id:'R1',name:'R1',mode:'bus'},{id:'R2',name:'R2',mode:'rail'}],trips:[{id:'T1',routeId:'R1',serviceId:'S'},{id:'T2',routeId:'R2',serviceId:'S'}],stopTimes:[{tripId:'T1',stopId:'A',sequence:1,arrivalSeconds:33000,departureSeconds:33000},{tripId:'T1',stopId:'B',sequence:2,arrivalSeconds:34200,departureSeconds:34200},{tripId:'T2',stopId:'C',sequence:1,arrivalSeconds:35600,departureSeconds:35600},{tripId:'T2',stopId:'D',sequence:2,arrivalSeconds:37500,departureSeconds:37500}],calendars:[week],exceptions:[]};
 const seen=[];
 const matcher=(a,b)=> {const eq=(x,y)=>x.lat===y.lat&&x.lon===y.lon;
   if(eq(a,co.O)&&eq(b,co.A))return makePath(a,b,0,0);
   if(eq(a,co.D)&&eq(b,co.Z))return makePath(a,b,0,0);
   if(eq(a,co.B)&&eq(b,co.C))return makePath(a,b,250,900);
   return null;
 };
 const router={walk:async (a,b)=>{seen.push([a,b]);return matcher(a,b)}};
 const opts={modes:['bus','rail'],maxRequestCount:24,maxOriginStops:4,maxDestinationStops:4,maxTransferPairs:10,maxDirectWalkMeters:0};
 const req={serviceDate:DT,departAfterSeconds:t0,maxTransfers:1,maxWalkingMeters:2000,origin:co.O,destination:co.Z};
 const planned=await planDoorToDoor(data,router,req,opts);
 const fullPaths={origin:co.O,destination:co.Z,access:[{stopId:'A',...makePath(co.O,co.A,0,0)}],egress:[{stopId:'D',...makePath(co.D,co.Z,0,0)}],transfers:[{fromStopId:'B',toStopId:'C',...makePath(co.B,co.C,250,900)}]};
 const engineControl=planJourneys(data,fullPaths,req);
 return {gapMetersApprox:Math.round(gap*111_200),planningJourneys:planned.journeys.length,engineWithSuppliedWalk:engineControl.length,walkCalls:seen.length,bToCCalled:seen.some(([a,b])=>a.lat===co.B.lat&&b.lat===co.C.lat),coverage:planned.coverage};
}
(async()=>{
 for(const gap of [0.0045,0.0075])console.log('CASE-02 transfer search radius',JSON.stringify(await transferCase(gap)));
 const good='<ArrayOfObjStationData><objStationData><Traincode>A123</Traincode><Stationfullname>Ballina</Stationfullname></objStationData></ArrayOfObjStationData>';
 const badRoot='<ArrayOfObjStationData><objStationData><Traincode>A123</Traincode><Stationfullname>Ballina</Stationfullname></objStationData></arrayofobjstationdata>';
 const badPref='<x:ArrayOfObjStationData><objStationData><Traincode>A123</Traincode><Stationfullname>Ballina</Stationfullname></objStationData></y:ArrayOfObjStationData>';
 const attempt=x=>{try{return {accepted:true,services:parseIrishRailStationXml(x,'Ballina','2026-10-08T10:00:00Z').services.length}}catch(e){return {accepted:false,error:e.message}}};
 console.log('CASE-03 malformed-root-controls',JSON.stringify({good:attempt(good),mismatchedCase:attempt(badRoot),mismatchedPrefix:attempt(badPref)}));
})().catch(e=>{console.error(e.stack);process.exitCode=1});
