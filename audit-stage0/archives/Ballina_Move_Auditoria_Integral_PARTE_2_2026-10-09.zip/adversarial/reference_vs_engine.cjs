const {planJourneys}=require('../source/routing/dist/index.js');
const dataDate='2026-10-08', start=9*3600;
let randomSeed=0;
function rng(seed){let x=seed|0;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296}}
function model(seed){const rand=rng(seed);const stopNames=['A','B','C','D','E'];const xy=Object.fromEntries([...stopNames,'O','Z'].map((id,i)=>[id,{lat:54.1+i*.002,lon:-9.2}]));
let trips=[],stopTimes=[],routes=[];
for(let i=0;i<12;i++){
 const sampled=stopNames.slice().sort(()=>rand()-.5).slice(0,2+Math.floor(rand()*3));
 const stops=sampled.filter((x,i)=>sampled.indexOf(x)===i);
 let depart=start+60*Math.floor(rand()*90);
 const tripId='T'+i;trips.push({id:tripId,routeId:'R'+i,serviceId:'WK'});routes.push({id:'R'+i,name:'R'+i,mode:rand()<.3?'rail':'bus'});
 for(let j=0;j<stops.length;j++){
    if(j>0)depart+=60*(2+Math.floor(rand()*25));
    stopTimes.push({tripId,stopId:stops[j],sequence:j+1,arrivalSeconds:depart,departureSeconds:depart});
 }
}
const db={feedVersion:'ref-fixture',timezone:'Europe/Dublin',stops:stopNames.map(id=>({id,name:id,...xy[id]})),routes,trips,stopTimes,calendars:[{serviceId:'WK',startDate:'2026-10-01',endDate:'2026-10-31',weekdays:[true,true,true,true,true,true,true]}],exceptions:[]};
const walk={origin:xy.O,destination:xy.Z,access:[{stopId:'A',durationSeconds:0,distanceMeters:0,geometry:[xy.O,xy.A],provider:'ref'}],egress:[{stopId:'E',durationSeconds:0,distanceMeters:0,geometry:[xy.E,xy.Z],provider:'ref'}],transfers:[]};
return {db,walk,start,xy};}
function exhaustive(db,walk,start,maxTransfers=2){
 const stopsByTrip=new Map();for(let t of db.trips)stopsByTrip.set(t.id,db.stopTimes.filter(s=>s.tripId===t.id).sort((a,b)=>a.sequence-b.sequence));
 const out=[];let explored=0;
 function visit(stop,at,visited,rides){if(rides>maxTransfers+1)return;if(rides>=1&&stop==='E'){out.push({arrival:at,tripPattern:visited.join('|')});}if(rides>=maxTransfers+1)return;
 for(let [tid,rows] of stopsByTrip){if(visited.includes(tid))continue;for(let i=0;i<rows.length-1;i++){
 if(rows[i].stopId!==stop || rows[i].departureSeconds<at+(rides?120:60))continue;
 for(let j=i+1;j<rows.length;j++){
  explored++;
  visit(rows[j].stopId,rows[j].arrivalSeconds,[...visited,tid],rides+1);
 }
 }}
 }
 visit('A',start,[],0);return {best:out.length?Math.min(...out.map(x=>x.arrival)):null,count:out.length,explored,potential:out.sort((a,b)=>a.arrival-b.arrival).slice(0,4)};
}
const bad=[];let eligible=0;const t0=Date.now();for(let seed=1;seed<=3000;seed++){
 let {db,walk,start}=model(seed);let expectation=exhaustive(db,walk,start);
 if(expectation.best===null)continue;eligible++;
 let found=planJourneys(db,walk,{serviceDate:dataDate,departAfterSeconds:start,maxTransfers:2,minTransferSeconds:120,minBoardingSeconds:60,limit:5});let best=found.length?Math.min(...found.map(x=>x.arrivalAtSeconds)):null;
 if(best!==expectation.best){bad.push({seed,expected:expectation.best,actual:best,expectation,found:found.map(x=>({at:x.arrivalAtSeconds,pattern:x.legs.filter(l=>l.type==='ride').map(l=>l.tripId)})),db,walk});if(bad.length>=5)break}
}
console.log(JSON.stringify({cases:3000,eligible,ms:Date.now()-t0,discrepancies:bad.map(({seed,expected,actual,expectation,found})=>({seed,expected,actual,expectation,found}))},null,2));
require('node:fs').writeFileSync('/mnt/data/ballina_audit_part2/adversarial/reference_counterexamples.json',JSON.stringify(bad,null,2));
