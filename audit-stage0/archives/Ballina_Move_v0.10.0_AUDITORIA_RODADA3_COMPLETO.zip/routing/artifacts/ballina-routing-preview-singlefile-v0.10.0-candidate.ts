import "jsr:@supabase/functions-js/edge-runtime.d.ts";
// Generated locally from src/*.ts. Do not edit by hand.
// Module functions are compiled TypeScript, not runtime eval or dynamic imports.
const __ballinaModules = {
  './boarding': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.USER_SNAP_CONFIRMATION_METERS = exports.MAX_USER_ENDPOINT_DRIFT_METERS = exports.MAX_WALK_ENDPOINT_DRIFT_METERS = void 0;
exports.boardingInstruction = boardingInstruction;
exports.proximityMeters = proximityMeters;
exports.routableStopCoordinate = routableStopCoordinate;
/** Provisional snapped-point tolerances, independent of boarding-bay verification. */
exports.MAX_WALK_ENDPOINT_DRIFT_METERS = 25; // Stops: do not infer a boarding bay from a snapped road.
exports.MAX_USER_ENDPOINT_DRIFT_METERS = 50; // Provisional conservative cap pending measured road-snap histogram.
exports.USER_SNAP_CONFIRMATION_METERS = 25; // UI must ask rider to verify snapped road point above this distance.
function boardingInstruction(stop) {
    const conf = stop.boarding?.confidence === 'verified' && !!stop.boarding.sourceUrl && !!stop.boarding.verifiedAt
        ? 'verified' : 'official_unverified';
    return {
        stopId: stop.id, stopCode: stop.code ?? null, stopName: stop.name,
        coordinate: { lat: stop.lat, lon: stop.lon }, locationConfidence: conf,
        sideOfStreet: conf === 'verified' ? stop.boarding?.sideOfStreet ?? null : null,
        platform: conf === 'verified' ? stop.boarding?.platform ?? null : null,
        notes: conf === 'verified' ? stop.boarding?.note ?? null : null,
        caveat: conf === 'verified' ? null : 'Stop coordinates from GTFS; correct sidewalk or boarding bay not independently verified.'
    };
}
function proximityMeters(a, b) {
    const r = 6371000;
    const dlat = (b.lat - a.lat) * Math.PI / 180;
    const dlon = (b.lon - a.lon) * Math.PI / 180;
    const t = Math.sin(dlat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dlon / 2) ** 2;
    return 2 * r * Math.asin(Math.min(1, Math.sqrt(t)));
}
/** Only a sourced, dated review may redirect the pedestrian route away from the official coordinate. */
function routableStopCoordinate(stop) {
    if (stop.boarding?.confidence === 'verified' && stop.boarding.sourceUrl && stop.boarding.verifiedAt && stop.boarding.boardingPoint) {
        return { lat: stop.boarding.boardingPoint.lat, lon: stop.boarding.boardingPoint.lon };
    }
    return { lat: stop.lat, lon: stop.lon };
}

  },
  './boardingEvidence': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyBoardingEvidence = applyBoardingEvidence;
exports.journeyBoardingDetails = journeyBoardingDetails;
const boarding_1 = require("./boarding");
const datePattern = /^\d{4}-\d{2}-\d{2}$/;
const validPoint = (p) => Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180;
function validateEvidence(e) {
    const timestamp = datePattern.test(e.verifiedAt) ? Date.parse(e.verifiedAt + 'T00:00:00Z') : NaN;
    if (!e.stopId || !e.feedVersion || !e.reviewer?.trim() || !Number.isFinite(timestamp) ||
        new Date(timestamp).toISOString().slice(0, 10) !== e.verifiedAt || timestamp > Date.now()) {
        throw new Error('boarding_invalid_evidence');
    }
    const url = (() => { try {
        return new URL(e.sourceUrl);
    }
    catch {
        return null;
    } })();
    if (!url || url.protocol !== 'https:' || !url.hostname || url.username || url.password)
        throw new Error('boarding_invalid_source');
    if (e.boardingPoint && !validPoint(e.boardingPoint))
        throw new Error('boarding_invalid_coordinate');
}
/** A reviewed annotation is applied only to the GTFS version it was reviewed against. */
function applyBoardingEvidence(data, evidence) {
    const known = new Set(data.stops.map(s => s.id));
    const annotated = new Map();
    const byStop = new Map(data.stops.map(s => [s.id, s]));
    for (const e of evidence) {
        validateEvidence(e);
        if (e.feedVersion !== data.feedVersion)
            continue; // stale reviews cannot silently survive GTFS refresh
        if (!known.has(e.stopId))
            throw new Error('boarding_unknown_stop');
        if (annotated.has(e.stopId))
            throw new Error('boarding_duplicate_evidence');
        const stop = byStop.get(e.stopId);
        if (e.boardingPoint && (0, boarding_1.proximityMeters)(stop, e.boardingPoint) > 75)
            throw new Error('boarding_override_too_far_from_gtfs');
        annotated.set(e.stopId, e);
    }
    return { ...data, stops: data.stops.map(s => {
            const e = annotated.get(s.id);
            if (!e)
                return { ...s, boarding: { confidence: 'official_unverified' } };
            return { ...s, boarding: { confidence: 'verified',
                    sideOfStreet: e.sideOfStreet, platform: e.platform, note: e.accessNote,
                    boardingPoint: e.boardingPoint, sourceUrl: e.sourceUrl, verifiedAt: e.verifiedAt } };
        }) };
}
/** Keep the pedestrian arrival aligned with the separately verified boarding point. */
function verifiedBoardingPoint(stop) {
    return stop.boarding?.confidence === 'verified' && stop.boarding.sourceUrl && stop.boarding.verifiedAt && stop.boarding.boardingPoint
        ? stop.boarding.boardingPoint : { lat: stop.lat, lon: stop.lon };
}
/** These details drive the future "Where do I catch the bus?" card in the webapp. */
function journeyBoardingDetails(journey, stops) {
    const known = new Map(stops.map(s => [s.id, s]));
    const out = [];
    for (let i = 0; i < journey.legs.length; i++) {
        const leg = journey.legs[i];
        if (leg.type !== 'ride')
            continue;
        const stop = known.get(leg.boardStopId);
        if (!stop)
            throw new Error('boarding_stop_missing');
        const instruction = (0, boarding_1.boardingInstruction)(stop);
        const walk = journey.legs[i - 1];
        const relevantWalk = walk?.type === 'walk' && walk.purpose !== 'egress'
            && (0, boarding_1.proximityMeters)(walk.to, verifiedBoardingPoint(stop)) <= boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS ? walk : null;
        const verified = instruction.locationConfidence === 'verified' && !!stop.boarding?.sourceUrl;
        out.push({ ...instruction,
            boardingPoint: verified && stop.boarding?.boardingPoint ? stop.boarding.boardingPoint : { lat: stop.lat, lon: stop.lon },
            boardingPointSource: verified && stop.boarding?.boardingPoint ? 'verified_override' : 'official_gtfs',
            evidenceSourceUrl: verified ? stop.boarding?.sourceUrl ?? null : null,
            evidenceVerifiedAt: verified ? stop.boarding?.verifiedAt ?? null : null,
            walkingDistanceMeters: relevantWalk?.distanceMeters ?? null,
            walkingDurationSeconds: relevantWalk?.durationSeconds ?? null,
        });
    }
    return out;
}

  },
  './connections': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.journeyConnections = journeyConnections;
const boarding_1 = require("./boarding");
/** Explicit change instructions for the future map and step-by-step itinerary.
 * Uses only ride stops from the planner and pre-validated pedestrian leg geometry.
 * Never claims a particular platform without an independently sourced review. */
function journeyConnections(journey, stops) {
    const known = new Map(stops.map(s => [s.id, s]));
    const connections = [];
    let previous = null;
    for (const [index, leg] of journey.legs.entries()) {
        if (leg.type !== 'ride')
            continue;
        if (previous) {
            const prior = previous.ride;
            const from = known.get(prior.alightStopId);
            const to = known.get(leg.boardStopId);
            if (!from || !to)
                throw new Error('connection_unknown_stop');
            const middle = journey.legs.slice(previous.index + 1, index);
            if (middle.some(l => l.type !== 'walk' || l.purpose !== 'transfer') || middle.length > 1)
                throw new Error('connection_invalid_intermediate_legs');
            const walk = middle[0];
            if (from.id !== to.id && !walk)
                throw new Error('connection_missing_pedestrian_path');
            if (walk && (from.id === to.id ||
                (0, boarding_1.proximityMeters)(walk.from, (0, boarding_1.routableStopCoordinate)(from)) > boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS ||
                (0, boarding_1.proximityMeters)(walk.to, (0, boarding_1.routableStopCoordinate)(to)) > boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS))
                throw new Error('connection_unexpected_walk');
            const walkSecs = walk?.durationSeconds ?? 0;
            const window = leg.boardAtSeconds - prior.alightAtSeconds;
            if (window < walkSecs)
                throw new Error('connection_impossible_schedule');
            connections.push({
                kind: walk ? 'walk_between_stops' : 'same_stop',
                fromRoute: prior.routeName, toRoute: leg.routeName,
                alightStopId: from.id, alightStopName: from.name, alightStopCode: from.code ?? null,
                boardStopId: to.id, boardStopName: to.name, boardStopCode: to.code ?? null,
                alightAtSeconds: prior.alightAtSeconds, boardAtSeconds: leg.boardAtSeconds,
                transferWalkSeconds: walkSecs, transferWalkMeters: walk?.distanceMeters ?? 0,
                scheduledWindowSeconds: window, waitingAfterWalkSeconds: window - walkSecs,
                boarding: (0, boarding_1.boardingInstruction)(to), guaranteed: false,
                note: walk ? 'Walk between the indicated stops using the provided pedestrian route. Connection is scheduled, not guaranteed.' :
                    `Remain at the same GTFS stop for the next ${leg.mode === 'rail' ? 'train' : 'bus'}. Physical platform/bay is not confirmed unless independently verified.`,
            });
        }
        previous = { ride: leg, index };
    }
    return connections;
}

  },
  './engine': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nonDominatedJourneys = nonDominatedJourneys;
exports.planJourneys = planJourneys;
const time_1 = require("./time");
const boarding_1 = require("./boarding");
const MAX_SCHEDULE_SECONDS = 72 * 3600;
function assertPath(path, from, to, purpose) {
    if (!Number.isFinite(path.durationSeconds) || path.durationSeconds < 0 || path.durationSeconds > 7200)
        return false;
    if (!Number.isFinite(path.distanceMeters) || path.distanceMeters < 0 || path.distanceMeters > 5000)
        return false;
    if (!Array.isArray(path.geometry) || path.geometry.length < 2 || !path.provider)
        return false;
    if (!path.geometry.every(p => Number.isFinite(p.lat) && Number.isFinite(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180))
        return false;
    const first = path.geometry[0], last = path.geometry[path.geometry.length - 1];
    // A valid path must end at the GTFS stop, not just somewhere nearby in the road.
    // This checks endpoints only; sidewalk/platform certainty requires independent verification.
    const fromLimit = purpose === 'access' || purpose === 'direct' ? boarding_1.MAX_USER_ENDPOINT_DRIFT_METERS : boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS;
    const toLimit = purpose === 'egress' || purpose === 'direct' ? boarding_1.MAX_USER_ENDPOINT_DRIFT_METERS : boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS;
    return (0, boarding_1.proximityMeters)(first, from) <= fromLimit && (0, boarding_1.proximityMeters)(last, to) <= toLimit;
}
function pathLeg(path, from, to, purpose) {
    return { type: 'walk', from, to, durationSeconds: path.durationSeconds, distanceMeters: path.distanceMeters,
        geometry: path.geometry, provider: path.provider, purpose, ...(path.endpointSnapMeters ? { endpointSnapMeters: path.endpointSnapMeters } : {}),
        ...(path.unverifiedConnector ? { unverifiedConnector: path.unverifiedConnector } : {}),
        ...(path.snappedUserEndpoints ? { snappedUserEndpoints: path.snappedUserEndpoints } : {}),
        ...(path.requiresSnapConfirmation ? { requiresSnapConfirmation: true } : {}) };
}
/** Preserve arrival/walk/boarding trade-offs and future-trip eligibility.
 * The 24-label cap bounds work but is not a proof of globally optimal routing. */
const MAX_STATES_PER_STOP = 24;
const stateMetadata = new WeakMap();
function metadata(state) {
    const cached = stateMetadata.get(state);
    if (cached)
        return cached;
    const used = new Set();
    let last = null;
    for (const leg of state.legs)
        if (leg.type === 'ride') {
            last = `${leg.serviceDate}:${leg.tripId}`;
            used.add(last);
        }
    const item = { last, used, snap: snapConfirmationRequired(state.legs) };
    stateMetadata.set(state, item);
    return item;
}
function previousVehicle(state) {
    return metadata(state).last;
}
/** State A must not prohibit any trip that state B could still board.
 * The planner forbids reusing trip IDs, so history is part of state identity. */
function usedVehicles(state) {
    return metadata(state).used;
}
function snapConfirmationRequired(legs) {
    return legs.some(leg => leg.type === 'walk' && leg.requiresSnapConfirmation === true);
}
function stateDominates(a, b) {
    if (previousVehicle(a) !== previousVehicle(b) ||
        a.at > b.at || a.walkingMeters > b.walkingMeters || a.rides > b.rides)
        return false;
    // A label with uncertain household-to-street access cannot discard one
    // which does not require explicit confirmation from the passenger.
    if (metadata(a).snap && !metadata(b).snap)
        return false;
    const otherUsed = usedVehicles(b);
    for (const tripId of usedVehicles(a)) {
        if (!otherUsed.has(tripId))
            return false;
    }
    return true;
}
function addBest(states, state) {
    const entries = states.get(state.stopId) ?? [];
    const compare = (a, b) => a.at - b.at || a.walkingMeters - b.walkingMeters || a.rides - b.rides;
    // The bounded algorithm is approximate, but never lose a NEW minimum of
    // walking distance at the stop (critical for walking-constrained transfers).
    // This cheap gate prevents an O(24 log 24) selection on every later,
    // no-less-walk state in highly overlapping timetable feeds.
    if (entries.length >= MAX_STATES_PER_STOP && compare(state, entries[entries.length - 1]) >= 0 &&
        entries.some(x => metadata(x).snap === snapConfirmationRequired(state.legs))) {
        let comparable = 0;
        const distinct = new Set();
        for (const old of entries) {
            if (old.at <= state.at && old.walkingMeters <= state.walkingMeters && old.rides <= state.rides &&
                (!metadata(old).snap || snapConfirmationRequired(state.legs))) {
                const history = previousVehicle(old);
                if (history)
                    distinct.add(history);
                if (distinct.size >= 2) {
                    comparable = 2;
                    break;
                }
            }
        }
        // Preserve states that can be the *second* low-walk alternative when a
        // single earlier history may block reboarding an essential vehicle.
        if (comparable >= 2)
            return;
    }
    if (entries.some(x => stateDominates(x, state)))
        return;
    const viable = entries.filter(x => !stateDominates(state, x));
    viable.push(state);
    const byTime = compare;
    const byWalk = (a, b) => a.walkingMeters - b.walkingMeters || a.at - b.at || a.rides - b.rides;
    if (viable.length <= MAX_STATES_PER_STOP) {
        viable.sort(byTime);
        states.set(state.stopId, viable);
        return;
    }
    // Selecting only the earliest 24 suppresses late but low-walking feeders,
    // including the sole state that can afford a subsequent walking transfer.
    // Reserve earliest AND lowest-walking labels per snap-risk class. Then
    // distribute the remaining places equally between time and walking ranks.
    const selected = new Set();
    for (const snap of [false, true]) {
        const same = viable.filter(x => metadata(x).snap === snap);
        if (same.length) {
            selected.add(same.reduce((best, x) => byTime(x, best) < 0 ? x : best));
            selected.add(same.reduce((best, x) => byWalk(x, best) < 0 ? x : best));
        }
    }
    const orderedTime = [...viable].sort(byTime);
    const orderedWalk = [...viable].sort(byWalk);
    let ti = 0, wi = 0;
    while (selected.size < MAX_STATES_PER_STOP) {
        const prior = selected.size;
        while (ti < orderedTime.length && selected.has(orderedTime[ti]))
            ti++;
        if (ti < orderedTime.length && selected.size < MAX_STATES_PER_STOP)
            selected.add(orderedTime[ti++]);
        while (wi < orderedWalk.length && selected.has(orderedWalk[wi]))
            wi++;
        if (wi < orderedWalk.length && selected.size < MAX_STATES_PER_STOP)
            selected.add(orderedWalk[wi++]);
        if (selected.size === prior)
            break;
    }
    states.set(state.stopId, [...selected].sort(byTime));
}
function sortStopTimes(rows) { return [...rows].sort((a, b) => a.sequence - b.sequence); }
function scheduleIsValid(rows) {
    let previous = -1;
    for (const r of rows) {
        const a = r.arrivalSeconds, d = r.departureSeconds;
        if (a != null && (!Number.isInteger(a) || a < 0 || a > MAX_SCHEDULE_SECONDS || a < previous))
            return false;
        if (d != null && (!Number.isInteger(d) || d < 0 || d > MAX_SCHEDULE_SECONDS || (a != null && d < a) || d < previous))
            return false;
        if (a != null)
            previous = a;
        if (d != null)
            previous = d;
    }
    return true;
}
/** Pareto for completed journeys (not an exhaustive-route guarantee).
 * Later departure from origin is a benefit: otherwise every hourly bus after
 * the first disappears. departureAtSeconds is only the requested search time.
 * Legacy fixtures without the new field retain previous comparison behavior. */
function nonDominatedJourneys(journeys) {
    const leaveAt = (j) => Number.isFinite(j.latestLeaveAtSeconds) ? j.latestLeaveAtSeconds :
        Number.isFinite(j.departureAtSeconds) ? j.departureAtSeconds : 0;
    return journeys.filter((candidate, index) => !journeys.some((other, i) => i !== index &&
        !(Boolean(other.requiresSnapConfirmation || snapConfirmationRequired(other.legs ?? [])) &&
            !Boolean(candidate.requiresSnapConfirmation || snapConfirmationRequired(candidate.legs ?? []))) &&
        other.arrivalAtSeconds <= candidate.arrivalAtSeconds &&
        other.walkingMeters <= candidate.walkingMeters &&
        other.transfers <= candidate.transfers &&
        leaveAt(other) >= leaveAt(candidate) &&
        (other.arrivalAtSeconds < candidate.arrivalAtSeconds ||
            other.walkingMeters < candidate.walkingMeters ||
            other.transfers < candidate.transfers ||
            leaveAt(other) > leaveAt(candidate))));
}
function planJourneys(data, paths, request) {
    if (data.timezone !== 'Europe/Dublin')
        throw new Error('unsupported_timezone');
    if (!(0, time_1.validDate)(request.serviceDate))
        throw new Error('invalid_service_date');
    if ((0, time_1.dstTransitionDay)(request.serviceDate))
        throw new Error('dst_transition_requires_timezone_aware_scheduling');
    if (!Number.isInteger(request.departAfterSeconds) || request.departAfterSeconds < 0 || request.departAfterSeconds >= 86400)
        throw new Error('invalid_departure_time');
    const maxTransfers = Math.max(0, Math.min(2, Math.floor(request.maxTransfers ?? 1)));
    const limit = Math.max(1, Math.min(5, Math.floor(request.limit ?? 3)));
    const minBoarding = Math.max(0, Math.floor(request.minBoardingSeconds ?? 60));
    const minTransfer = Math.max(0, Math.floor(request.minTransferSeconds ?? 120));
    const walkingCap = Math.max(0, Math.floor(request.maxWalkingMeters ?? 2500));
    if (![minBoarding, minTransfer, walkingCap].every(Number.isFinite))
        throw new Error('invalid_parameters');
    const stopMap = new Map(data.stops.map(s => [s.id, s]));
    const routeMap = new Map(data.routes.map(r => [r.id, r]));
    const rowsByTrip = new Map();
    for (const row of data.stopTimes) {
        const a = rowsByTrip.get(row.tripId) ?? [];
        a.push(row);
        rowsByTrip.set(row.tripId, a);
    }
    const validTrips = [];
    const maxBoardTime = request.departAfterSeconds + 18 * 3600; // bounded departure horizon
    const serviceDays = [-1, 0, 1].map(offset => ({ offset, date: (0, time_1.offsetServiceDate)(request.serviceDate, offset) }));
    const serviceMemo = new Map();
    for (const trip of data.trips) {
        const route = routeMap.get(trip.routeId);
        if (!route)
            continue;
        const sourceRows = sortStopTimes(rowsByTrip.get(trip.id) ?? []);
        if (sourceRows.length < 2 || !scheduleIsValid(sourceRows))
            continue;
        for (const { offset, date } of serviceDays) {
            // A DST change needs transition-specific UTC conversion. Do not invent 24h days.
            if (offset !== 0 && (0, time_1.dstTransitionDay)(date))
                continue;
            const key = trip.serviceId + '|' + date;
            let active = serviceMemo.get(key);
            if (active === undefined) {
                active = (0, time_1.activeService)(trip.serviceId, date, data.calendars, data.exceptions);
                serviceMemo.set(key, active);
            }
            if (!active)
                continue;
            // Express every service-day event relative to the requested local date.
            // Previous day's 25:15 becomes 01:15; next day's 00:20 becomes 24:20.
            const delta = offset * 86400;
            const rows = sourceRows.map(r => ({ ...r,
                arrivalSeconds: r.arrivalSeconds === null ? null : r.arrivalSeconds + delta,
                departureSeconds: r.departureSeconds === null ? null : r.departureSeconds + delta }));
            if (!rows.some(r => r.departureSeconds !== null && r.departureSeconds >= request.departAfterSeconds && r.departureSeconds <= maxBoardTime))
                continue;
            validTrips.push({ trip, route, rows, serviceDate: date, serviceDayDelta: delta });
        }
    }
    // Index trips by stops where boarding is permitted. Each transfer round
    // examines only trips that can actually be reached from the frontier.
    const tripsByBoardingStop = new Map();
    for (let index = 0; index < validTrips.length; index++) {
        const seen = new Set();
        for (const row of validTrips[index].rows) {
            if (row.departureSeconds == null || !(row.pickupType == null || row.pickupType === 0) || seen.has(row.stopId))
                continue;
            seen.add(row.stopId);
            const list = tripsByBoardingStop.get(row.stopId) ?? [];
            list.push(index);
            tripsByBoardingStop.set(row.stopId, list);
        }
    }
    const egressPaths = new Map();
    for (const p of paths.egress) {
        const s = stopMap.get(p.stopId);
        if (s && assertPath(p, (0, boarding_1.routableStopCoordinate)(s), paths.destination, 'egress')) {
            const current = egressPaths.get(p.stopId);
            if (!current || p.durationSeconds < current.durationSeconds)
                egressPaths.set(p.stopId, p);
        }
    }
    const transferMap = new Map();
    for (const p of paths.transfers) {
        const from = stopMap.get(p.fromStopId), to = stopMap.get(p.toStopId);
        if (!from || !to || from.id === to.id || !assertPath(p, (0, boarding_1.routableStopCoordinate)(from), (0, boarding_1.routableStopCoordinate)(to), 'transfer'))
            continue;
        const old = transferMap.get(from.id) ?? [];
        old.push(p);
        transferMap.set(from.id, old);
    }
    const initial = new Map();
    for (const p of paths.access) {
        const stop = stopMap.get(p.stopId);
        if (!stop || !assertPath(p, paths.origin, (0, boarding_1.routableStopCoordinate)(stop), 'access') || p.distanceMeters > walkingCap)
            continue;
        addBest(initial, { stopId: stop.id, at: request.departAfterSeconds + p.durationSeconds, rides: 0,
            walkingMeters: p.distanceMeters, legs: [pathLeg(p, paths.origin, (0, boarding_1.routableStopCoordinate)(stop), 'access')], boardings: [] });
    }
    const candidates = [];
    // Walk-only is a real alternative, never a fabricated road line. Requires
    // separately returned provider geometry, and no GTFS service to exist.
    if (paths.direct && assertPath(paths.direct, paths.origin, paths.destination, 'direct') &&
        paths.direct.distanceMeters <= walkingCap) {
        candidates.push({ serviceDate: request.serviceDate, feedVersion: data.feedVersion,
            departureAtSeconds: request.departAfterSeconds,
            latestLeaveAtSeconds: request.departAfterSeconds,
            arrivalAtSeconds: request.departAfterSeconds + paths.direct.durationSeconds,
            transfers: 0, walkingMeters: paths.direct.distanceMeters,
            legs: [pathLeg(paths.direct, paths.origin, paths.destination, 'direct')],
            boardings: [], predictionType: 'walking_estimate' });
    }
    let frontier = initial;
    for (let round = 0; round <= maxTransfers; round++) {
        if (frontier.size === 0)
            break;
        const next = new Map();
        const reachableTrips = new Set();
        for (const stopId of frontier.keys())
            for (const index of tripsByBoardingStop.get(stopId) ?? [])
                reachableTrips.add(index);
        for (const tripIndex of [...reachableTrips].sort((a, b) => a - b)) {
            const { trip, route, rows, serviceDate, serviceDayDelta } = validTrips[tripIndex];
            const boardingCandidates = [];
            for (let i = 0; i < rows.length; i++) {
                const stopTime = rows[i];
                if ((stopTime.pickupType == null || stopTime.pickupType === 0) && stopTime.departureSeconds != null) {
                    for (const option of frontier.get(stopTime.stopId) ?? []) {
                        if (option.legs.some(leg => leg.type === 'ride' && leg.tripId === trip.id && leg.serviceDate === serviceDate))
                            continue;
                        const requireBuffer = option.rides > 0 ? minTransfer : minBoarding;
                        if (option.at + requireBuffer > stopTime.departureSeconds)
                            continue;
                        // The 18-hour search horizon applies to FIRST boarding, not to a
                        // connection after an already-valid first ride.
                        if (option.rides === 0 && stopTime.departureSeconds > maxBoardTime)
                            continue;
                        // Keep multiple boarding labels: a shorter access walk may enable
                        // a later transfer even if another label is faster at this stop.
                        boardingCandidates.push({ state: option, index: i });
                    }
                    if (boardingCandidates.length > 36) {
                        boardingCandidates.sort((a, b) => a.state.walkingMeters - b.state.walkingMeters ||
                            a.state.at - b.state.at || a.index - b.index);
                        boardingCandidates.splice(36);
                    }
                }
                if (stopTime.dropOffType === 1 || !(stopTime.dropOffType == null || stopTime.dropOffType === 0) || stopTime.arrivalSeconds == null)
                    continue;
                const alightStop = stopMap.get(stopTime.stopId);
                if (!alightStop)
                    continue;
                for (const chosen of boardingCandidates) {
                    if (chosen.index >= i)
                        continue;
                    const b = rows[chosen.index];
                    const boardingStop = stopMap.get(b.stopId);
                    if (!boardingStop)
                        continue;
                    const ride = { type: 'ride', tripId: trip.id, routeId: trip.routeId, routeName: route.name,
                        mode: route.mode, headsign: trip.headsign ?? null, boardStopId: b.stopId, alightStopId: stopTime.stopId,
                        boardAtSeconds: b.departureSeconds, alightAtSeconds: stopTime.arrivalSeconds,
                        boardAtServiceSeconds: b.departureSeconds - serviceDayDelta,
                        alightAtServiceSeconds: stopTime.arrivalSeconds - serviceDayDelta,
                        boardDayOffset: Math.floor((b.departureSeconds - serviceDayDelta) / 86400),
                        alightDayOffset: Math.floor((stopTime.arrivalSeconds - serviceDayDelta) / 86400), serviceDate };
                    const base = chosen.state;
                    const result = { stopId: stopTime.stopId, at: stopTime.arrivalSeconds, rides: base.rides + 1,
                        legs: [...base.legs, ride], boardings: [...base.boardings, (0, boarding_1.boardingInstruction)(boardingStop)],
                        walkingMeters: base.walkingMeters };
                    addBest(next, result);
                }
            }
        }
        // Transfer walking only after arriving on a vehicle. Never assume opposite sidewalks connect.
        const expanded = new Map();
        for (const group of next.values())
            for (const entry of group)
                addBest(expanded, entry);
        for (const group of next.values())
            for (const origin of group) {
                for (const p of transferMap.get(origin.stopId) ?? []) {
                    if (origin.walkingMeters + p.distanceMeters > walkingCap)
                        continue;
                    const from = stopMap.get(p.fromStopId), to = stopMap.get(p.toStopId);
                    addBest(expanded, { ...origin, stopId: to.id, at: origin.at + p.durationSeconds,
                        walkingMeters: origin.walkingMeters + p.distanceMeters,
                        legs: [...origin.legs, pathLeg(p, (0, boarding_1.routableStopCoordinate)(from), (0, boarding_1.routableStopCoordinate)(to), 'transfer')] });
                }
            }
        for (const group of next.values())
            for (const result of group) {
                const egress = egressPaths.get(result.stopId);
                if (!egress || result.walkingMeters + egress.distanceMeters > walkingCap)
                    continue;
                const stop = stopMap.get(result.stopId);
                const firstRide = result.legs.find((leg) => leg.type === 'ride');
                const access = result.legs.find((leg) => leg.type === 'walk' && leg.purpose === 'access');
                // Include required boarding slack: later advertised departures must
                // remain physically reachable, not just convenient-looking timestamps.
                const latestLeaveAtSeconds = firstRide
                    ? firstRide.boardAtSeconds - (access?.durationSeconds ?? 0) - minBoarding
                    : request.departAfterSeconds;
                candidates.push({ serviceDate: request.serviceDate, feedVersion: data.feedVersion,
                    departureAtSeconds: request.departAfterSeconds, latestLeaveAtSeconds,
                    arrivalAtSeconds: result.at + egress.durationSeconds,
                    transfers: result.rides - 1, walkingMeters: result.walkingMeters + egress.distanceMeters,
                    boardings: result.boardings, legs: [...result.legs, pathLeg(egress, (0, boarding_1.routableStopCoordinate)(stop), paths.destination, 'egress')],
                    predictionType: 'scheduled' });
            }
        frontier = expanded;
    }
    // Preserve alternatives with different transit patterns, then rank by actual scheduled arrival.
    const journeys = new Map();
    for (const c of candidates) {
        const signature = (c.legs.some(l => l.type === 'ride') ? c.legs.filter(l => l.type === 'ride').map(l => `${l.serviceDate}:${l.tripId}:${l.boardStopId}:${l.alightStopId}`).join('|') : 'walk_only') +
            (snapConfirmationRequired(c.legs) ? ':snap-confirmation' : ':no-snap-confirmation');
        const previous = journeys.get(signature);
        if (!previous || c.arrivalAtSeconds < previous.arrivalAtSeconds)
            journeys.set(signature, c);
    }
    const rankBy = request.rankBy ?? 'fastest';
    return nonDominatedJourneys([...journeys.values()]).sort((a, b) => {
        if (rankBy === 'less_walking')
            return a.walkingMeters - b.walkingMeters || a.arrivalAtSeconds - b.arrivalAtSeconds || a.transfers - b.transfers;
        if (rankBy === 'fewest_transfers')
            return a.transfers - b.transfers || a.arrivalAtSeconds - b.arrivalAtSeconds || a.walkingMeters - b.walkingMeters;
        return a.arrivalAtSeconds - b.arrivalAtSeconds || a.transfers - b.transfers || a.walkingMeters - b.walkingMeters;
    }).slice(0, limit).map(j => {
        const walks = j.legs.filter((l) => l.type === 'walk');
        return { ...j,
            unverifiedConnectorMeters: walks.reduce((s, l) => s + (l.unverifiedConnector?.meters ?? 0), 0),
            unverifiedConnectorSeconds: walks.reduce((s, l) => s + (l.unverifiedConnector?.estimatedSeconds ?? 0), 0),
            requiresSnapConfirmation: walks.some(l => l.requiresSnapConfirmation === true) };
    });
}

  },
  './gtfsSnapshot': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadActiveGtfsSnapshot = loadActiveGtfsSnapshot;
const supabaseAdapter_1 = require("./supabaseAdapter");
const TABLES = {
    stops: ['gtfs_stops', 'version,stop_id,stop_name,stop_lat,stop_lon,stop_code,stop_desc', 'stop_id.asc'],
    routes: ['gtfs_routes', 'version,route_id,route_short_name,route_long_name,route_type', 'route_id.asc'],
    trips: ['gtfs_trips', 'version,trip_id,route_id,service_id,trip_headsign', 'trip_id.asc'],
    stopTimes: ['gtfs_stop_times', 'version,trip_id,stop_id,stop_sequence,arrival_seconds,departure_seconds,pickup_type,drop_off_type', 'trip_id.asc,stop_sequence.asc'],
    calendars: ['gtfs_calendars', 'version,service_id,start_date,end_date,sunday,monday,tuesday,wednesday,thursday,friday,saturday', 'service_id.asc'],
    calendarDates: ['gtfs_calendar_dates', 'version,service_id,service_date,exception_type', 'service_id.asc,service_date.asc'],
};
async function loadActiveGtfsSnapshot(options) {
    const { supabaseUrl, privateKey } = options;
    if (!/^https:\/\//.test(supabaseUrl) || !privateKey || /\s/.test(privateKey))
        throw new Error('invalid_server_configuration');
    const pageSize = options.pageSize ?? 1000;
    const maxRows = options.maxRowsPerTable ?? 100_000;
    const timeoutMs = options.timeoutMs ?? 20_000;
    if (!Number.isInteger(pageSize) || pageSize < 1 || pageSize > 1000 || !Number.isInteger(maxRows) || maxRows < pageSize || !Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 60_000) {
        throw new Error('invalid_snapshot_options');
    }
    const fetcher = options.fetcher ?? fetch;
    const root = supabaseUrl.replace(/\/$/, '') + '/rest/v1/';
    const headers = { apikey: privateKey, Accept: 'application/json' };
    if (privateKey.startsWith('eyJ'))
        headers.Authorization = `Bearer ${privateKey}`;
    async function requestPage(path, withCount = false) {
        // Count only first page; if no reliable count header, fall back to serial pagination.
        const url = root + path;
        const pageHeaders = withCount ? { ...headers, Prefer: 'count=exact' } : headers;
        const response = await fetcher(url, { method: 'GET', headers: pageHeaders, signal: AbortSignal.timeout(timeoutMs) });
        if (!response.ok)
            throw new Error(`snapshot_http_${response.status}`);
        const rows = await response.json();
        if (!Array.isArray(rows) || !rows.every(x => x !== null && typeof x === 'object' && !Array.isArray(x)))
            throw new Error('invalid_snapshot_response');
        const header = withCount ? response.headers.get('content-range') : null;
        const match = header?.match(/^(?:\d+-\d+|\*)\/(\d+)$/);
        const total = match ? Number(match[1]) : null;
        if (total !== null && (!Number.isSafeInteger(total) || total < 0))
            throw new Error('invalid_snapshot_count');
        return { rows: rows, total };
    }
    async function request(path) { return (await requestPage(path)).rows; }
    async function activeVersion() {
        const rows = await request('gtfs_feed_versions?select=version&active=eq.true&label=eq.nta-realtime&limit=2');
        if (rows.length !== 1 || typeof rows[0]?.version !== 'string' || !rows[0].version)
            throw new Error('active_feed_unavailable_or_ambiguous');
        return rows[0].version;
    }
    const version = await activeVersion();
    const tables = {};
    async function loadGroup(group) {
        const [table, select, order] = TABLES[group];
        const path = (offset) => `${table}?select=${select}&version=eq.${encodeURIComponent(version)}&order=${order}&limit=${pageSize}&offset=${offset}`;
        const first = await requestPage(path(0), true);
        const all = [];
        const validate = (rows) => {
            if (rows.length > pageSize)
                throw new Error(`snapshot_page_overflow_${table}`);
            if (rows.some(r => r.version !== version))
                throw new Error(`mixed_gtfs_version_${table}`);
            all.push(...rows);
            if (all.length > maxRows)
                throw new Error(`snapshot_limit_exceeded_${table}`);
        };
        validate(first.rows);
        if (first.total !== null) {
            const total = first.total;
            if (total > maxRows)
                throw new Error(`snapshot_limit_exceeded_${table}`);
            if (first.rows.length !== Math.min(total, pageSize))
                throw new Error('snapshot_count_mismatch');
            // 3 outstanding pages per table, 2 table groups in parallel: <=6 total HTTP requests.
            for (let offset = pageSize; offset < total; offset += 3 * pageSize) {
                const offsets = Array.from({ length: 3 }, (_, i) => offset + i * pageSize).filter(n => n < total);
                const pages = await Promise.all(offsets.map(n => request(path(n))));
                pages.forEach((rows, i) => {
                    if (rows.length !== Math.min(pageSize, total - offsets[i]))
                        throw new Error('snapshot_count_mismatch');
                    validate(rows);
                });
            }
            if (all.length !== total)
                throw new Error('snapshot_count_mismatch');
        }
        else {
            // Intermediaries or older mocks without Content-Range: full, conservative fallback.
            for (let offset = pageSize; first.rows.length === pageSize; offset += pageSize) {
                if (offset > maxRows)
                    throw new Error(`snapshot_limit_exceeded_${table}`);
                const rows = await request(path(offset));
                validate(rows);
                if (rows.length < pageSize)
                    break;
            }
        }
        tables[group] = all;
    }
    const groups = Object.keys(TABLES);
    for (let i = 0; i < groups.length; i += 2)
        await Promise.all(groups.slice(i, i + 2).map(loadGroup));
    // Detect a new feed activation while pages were being fetched, instead of mixing datasets.
    if (await activeVersion() !== version)
        throw new Error('active_feed_switched_during_snapshot');
    if (!tables.stops.length || !tables.routes.length || !tables.trips.length || !tables.stopTimes.length)
        throw new Error('incomplete_snapshot');
    const timetable = (0, supabaseAdapter_1.fromSupabaseTables)({ feedVersion: version, ...tables });
    const knownStops = new Set(timetable.stops.map(s => s.id));
    const knownRoutes = new Set(timetable.routes.map(r => r.id));
    if (timetable.trips.some(t => !knownRoutes.has(t.routeId)) || timetable.stopTimes.some(st => !knownStops.has(st.stopId))) {
        throw new Error('snapshot_broken_references');
    }
    return timetable;
}

  },
  './httpApi': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rankItineraries = rankItineraries;
exports.createRoutingApi = createRoutingApi;
exports.createMemoryRateLimiter = createMemoryRateLimiter;
exports.createSnapshotCache = createSnapshotCache;
const time_1 = require("./time");
const planner_1 = require("./planner");
const engine_1 = require("./engine");
const boardingEvidence_1 = require("./boardingEvidence");
const connections_1 = require("./connections");
const nearbyStops_1 = require("./nearbyStops");
const irishRail_1 = require("./irishRail");
const BODY_LIMIT = 4096;
const IRELAND = { minLat: 51.3, maxLat: 55.8, minLon: -11.1, maxLon: -5.2 };
const hardenHeaders = {
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    'Vary': 'Origin',
};
function json(value, status = 200, extra = {}) {
    return new Response(JSON.stringify(value), { status, headers: { ...hardenHeaders, 'Content-Type': 'application/json; charset=utf-8', ...extra } });
}
function isObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function inIreland(value) {
    if (!isObject(value) || Object.keys(value).some(k => k !== 'lat' && k !== 'lon'))
        return false;
    const { lat, lon } = value;
    return typeof lat === 'number' && Number.isFinite(lat) && lat >= IRELAND.minLat && lat <= IRELAND.maxLat &&
        typeof lon === 'number' && Number.isFinite(lon) && lon >= IRELAND.minLon && lon <= IRELAND.maxLon;
}
function calendarDays(a, b) {
    return Math.floor((Date.parse(a + 'T00:00:00Z') - Date.parse(b + 'T00:00:00Z')) / 86400000);
}
function parseInput(raw, now) {
    if (!isObject(raw))
        return null;
    const keys = ['serviceDate', 'departAt', 'origin', 'destination', 'maxTransfers', 'maxWalkingMeters', 'limit', 'prioritize', 'modes'];
    if (Object.keys(raw).some(k => !keys.includes(k)))
        return null;
    const serviceDate = raw.serviceDate;
    const departAt = raw.departAt;
    if (typeof serviceDate !== 'string' || !(0, time_1.validDate)(serviceDate))
        return null;
    // Protect against arbitrary historic browsing and long-range provider consumption.
    const dateParts = new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Dublin', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
    const getDate = (name) => dateParts.find(part => part.type === name)?.value ?? '';
    const localToday = `${getDate('year')}-${getDate('month')}-${getDate('day')}`;
    const delta = calendarDays(serviceDate, localToday);
    if (!Number.isFinite(delta) || delta < 0 || delta > 14)
        return null;
    if (typeof departAt !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(departAt))
        return null;
    if (!inIreland(raw.origin) || !inIreland(raw.destination))
        return null;
    const maxTransfers = raw.maxTransfers ?? 1, maxWalkingMeters = raw.maxWalkingMeters ?? 2000, limit = raw.limit ?? 3;
    const prioritize = raw.prioritize ?? 'fastest';
    if (prioritize !== 'fastest' && prioritize !== 'less_walking' && prioritize !== 'fewest_transfers')
        return null;
    if (typeof maxTransfers !== 'number' || typeof maxWalkingMeters !== 'number' || typeof limit !== 'number' ||
        !Number.isInteger(maxTransfers) || maxTransfers < 0 || maxTransfers > 2 ||
        !Number.isInteger(maxWalkingMeters) || maxWalkingMeters < 100 || maxWalkingMeters > 2500 ||
        !Number.isInteger(limit) || limit < 1 || limit > 3)
        return null;
    const modesRaw = Object.prototype.hasOwnProperty.call(raw, 'modes') ? raw.modes : ['bus'];
    if (!Array.isArray(modesRaw) || modesRaw.length < 1 || modesRaw.length > 2 ||
        modesRaw.some(m => m !== 'bus' && m !== 'rail') || new Set(modesRaw).size !== modesRaw.length)
        return null;
    const modes = modesRaw;
    return { serviceDate, departAt, origin: raw.origin, destination: raw.destination, maxTransfers, maxWalkingMeters, limit, prioritize, modes };
}
async function readLimitedJson(req) {
    if (!req.body)
        throw new Error('missing_body');
    const header = req.headers.get('content-length');
    if (header && (!/^\d+$/.test(header) || Number(header) > BODY_LIMIT))
        throw new Error('payload_too_large');
    const reader = req.body.getReader();
    let count = 0;
    const chunks = [];
    try {
        for (;;) {
            const result = await reader.read();
            if (result.done)
                break;
            count += result.value.byteLength;
            if (count > BODY_LIMIT)
                throw new Error('payload_too_large');
            chunks.push(result.value);
        }
    }
    catch (error) {
        await reader.cancel().catch(() => undefined);
        throw error;
    }
    finally {
        reader.releaseLock();
    }
    const bytes = new Uint8Array(count);
    let offset = 0;
    for (const chunk of chunks) {
        bytes.set(chunk, offset);
        offset += chunk.byteLength;
    }
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
}
/** Bounded stop discovery is a geographic lookup, not proof of walking access. */
function parseNearby(url) {
    const keys = [];
    url.searchParams.forEach((_value, key) => { keys.push(key); });
    if (keys.some(k => !['lat', 'lon', 'radiusMeters', 'limit'].includes(k)))
        return null;
    if (new Set(keys).size !== keys.length)
        return null;
    const latString = url.searchParams.get('lat'), lonString = url.searchParams.get('lon');
    if (!latString || !lonString || !/^-?\d{1,2}(?:\.\d{1,7})?$/.test(latString) || !/^-?\d{1,3}(?:\.\d{1,7})?$/.test(lonString))
        return null;
    const origin = { lat: Number(latString), lon: Number(lonString) };
    if (!inIreland(origin))
        return null;
    const radiusText = url.searchParams.get('radiusMeters') ?? '1200', limitText = url.searchParams.get('limit') ?? '8';
    if (!/^\d{1,4}$/.test(radiusText) || !/^\d{1,2}$/.test(limitText))
        return null;
    const radiusMeters = Number(radiusText), limit = Number(limitText);
    if (radiusMeters < 100 || radiusMeters > 2500 || limit < 1 || limit > 15)
        return null;
    return { origin, radiusMeters, limit };
}
function rankItineraries(journeys, preference, limit) {
    const copy = (0, engine_1.nonDominatedJourneys)(journeys);
    copy.sort((a, b) => {
        if (preference === 'less_walking')
            return a.walkingMeters - b.walkingMeters || a.arrivalAtSeconds - b.arrivalAtSeconds || a.transfers - b.transfers;
        if (preference === 'fewest_transfers')
            return a.transfers - b.transfers || a.arrivalAtSeconds - b.arrivalAtSeconds || a.walkingMeters - b.walkingMeters;
        return a.arrivalAtSeconds - b.arrivalAtSeconds || a.transfers - b.transfers || a.walkingMeters - b.walkingMeters;
    });
    return copy.slice(0, limit);
}
function createRoutingApi(deps) {
    if (!deps.loadTimetable || !deps.router || !deps.clientIdentity || !deps.consumeRateLimit)
        throw new Error('missing_routing_api_dependencies');
    const permitted = new Set(deps.allowedOrigins ?? []);
    function report(stage, e, requestId) {
        // Only stable error codes from our own code; upstream error messages can contain secrets.
        const message = e instanceof Error ? e.message : '';
        const code = (e instanceof Error && (e.name === 'TimeoutError' || e.name === 'AbortError')) ? 'request_timeout' : /^(snapshot_http_(?:400|401|403|404|408|409|413|429|500|502|503|504)|active_feed_(?:unavailable_or_ambiguous|switched_during_snapshot)|mixed_gtfs_version_[a-z_]+|snapshot_(?:page_overflow|limit_exceeded)_[a-z_]+|incomplete_snapshot|snapshot_broken_references|walking_api_failed_(?:400|401|403|404|408|429|500|502|503|504)|invalid_polyline|invalid_snapshot_response|invalid_snapshot_count|snapshot_count_mismatch|rate_limiter_unavailable|invalid_rate_limiter_response|request_timeout|provider_timeout)$/.test(message)
            ? message : 'unexpected_error';
        try {
            deps.reportError?.({ stage, code, requestId });
        }
        catch { /* telemetry cannot change response */ }
    }
    return async (req) => {
        const requestId = crypto.randomUUID();
        const origin = req.headers.get('origin');
        const cors = origin && permitted.has(origin) ? {
            'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Max-Age': '600',
        } : {};
        if (origin && !permitted.has(origin))
            return json({ error: 'origin_not_allowed' }, 403);
        if (req.method === 'OPTIONS')
            return new Response(null, { status: 204, headers: { ...hardenHeaders, ...cors } });
        const pathname = new URL(req.url).pathname;
        if (pathname === '/health' && req.method === 'GET')
            return json({ status: 'available', service: 'ballina-routing-api', realtime: false }, 200, cors);
        const isNearby = pathname === '/v1/nearby-stops';
        const isRailBoard = pathname === '/v1/rail/station-board';
        const isRailStations = pathname === '/v1/rail/stations';
        if (pathname !== '/v1/journeys' && !isNearby && !isRailBoard && !isRailStations)
            return json({ error: 'not_found' }, 404, cors);
        if ((isNearby || isRailBoard || isRailStations) ? req.method !== 'GET' : req.method !== 'POST')
            return json({ error: 'method_not_allowed' }, 405, cors);
        if (!isNearby && !isRailBoard && !isRailStations) {
            const mediaType = req.headers.get('content-type')?.split(';', 1)[0]?.trim().toLowerCase();
            if (mediaType !== 'application/json')
                return json({ error: 'unsupported_media_type' }, 415, cors);
        }
        try {
            // Two independent limits. All unauthenticated clients share a global ceiling.
            if (!await deps.consumeRateLimit('routing|global', 200, 60))
                return json({ error: 'rate_limited' }, 429, { ...cors, 'Retry-After': '60' });
            const identity = deps.clientIdentity(req) || 'unidentified';
            // Protect limiter storage from unlimited arbitrary caller-controlled bucket strings.
            const safeIdentity = identity.slice(0, 120);
            if (!await deps.consumeRateLimit(`routing|client|${safeIdentity}`, 10, 60))
                return json({ error: 'rate_limited' }, 429, { ...cors, 'Retry-After': '60' });
        }
        catch (e) {
            report('rate_limit', e, requestId);
            return json({ error: 'temporarily_unavailable', requestId }, 503, cors);
        }
        if (isRailStations) {
            const url = new URL(req.url);
            if ([...url.searchParams.keys()].length)
                return json({ error: 'invalid_rail_stations_query' }, 400, cors);
            try {
                const timetable = await deps.loadTimetable();
                const railRouteIds = new Set(timetable.routes.filter(r => r.mode === 'rail').map(r => r.id));
                const railTrips = new Set(timetable.trips.filter(t => railRouteIds.has(t.routeId)).map(t => t.id));
                const usedStops = new Set(timetable.stopTimes.filter(st => railTrips.has(st.tripId)).map(st => st.stopId));
                const matched = timetable.stops.filter(s => usedStops.has(s.id)).sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));
                return json({ feedVersion: timetable.feedVersion, source: 'NTA_GTFS', mode: 'rail', realtime: false,
                    stations: matched.slice(0, 250).map(s => ({ stopId: s.id, name: s.name, coordinate: { lat: s.lat, lon: s.lon }, platformVerified: false })),
                    truncated: matched.length > 250,
                    caveat: 'GTFS station coordinates do not independently confirm platform or boarding access.' }, 200, cors);
            }
            catch (e) {
                report('rail', e, requestId);
                return json({ error: 'temporarily_unavailable', requestId }, 503, cors);
            }
        }
        if (isRailBoard) {
            // The upstream station-board endpoint is optional and must be explicitly wired.
            // This is NOT proof that an advertised time was observed on the rail network.
            const u = new URL(req.url);
            const keys = [...u.searchParams.keys()];
            if (keys.length !== 1 || keys[0] !== 'station')
                return json({ error: 'invalid_rail_station' }, 400, cors);
            const search = u.searchParams.get('station') ?? '';
            if (search.length > 60 || !/^[A-Za-z][A-Za-z '-]{1,58}$/.test(search))
                return json({ error: 'invalid_rail_station' }, 400, cors);
            if (!deps.getRailStationBoard)
                return json({ error: 'rail_board_not_configured' }, 503, cors);
            try {
                if (!await deps.consumeRateLimit('rail|station-board|global', 30, 60))
                    return json({ error: 'rate_limited' }, 429, { ...cors, 'Retry-After': '60' });
                const timetable = await deps.loadTimetable();
                const railRouteIds = new Set(timetable.routes.filter(r => r.mode === 'rail').map(r => r.id));
                const railTripIds = new Set(timetable.trips.filter(t => railRouteIds.has(t.routeId)).map(t => t.id));
                const railStopIds = new Set(timetable.stopTimes.filter(t => railTripIds.has(t.tripId)).map(t => t.stopId));
                const station = timetable.stops.find(s => railStopIds.has(s.id) && s.name.toLowerCase() === search.toLowerCase())?.name;
                if (!station)
                    return json({ error: 'unknown_rail_station' }, 404, cors);
                const board = await deps.getRailStationBoard(station);
                return json({ ...board, coverageWarning: irishRail_1.IRISH_RAIL_COVERAGE_WARNING, realtimeVerified: false }, 200, cors);
            }
            catch (e) {
                report('rail', e, requestId);
                return json({ error: 'rail_board_temporarily_unavailable', requestId }, 503, cors);
            }
        }
        if (isNearby) {
            const input = parseNearby(new URL(req.url));
            if (!input)
                return json({ error: 'invalid_nearby_request' }, 400, cors);
            try {
                const timetable = await deps.loadTimetable();
                return json({ feedVersion: timetable.feedVersion, stops: (0, nearbyStops_1.nearbyStops)(timetable, input.origin, input.radiusMeters, input.limit),
                    distanceType: 'straight_line_approximation_not_walking_route',
                    boardingNote: 'Stop pole, correct sidewalk or bay remain unverified without independent evidence.',
                    realtime: false, attribution: 'National Transport Authority (NTA) / GTFS timetable data' }, 200, cors);
            }
            catch (e) {
                report('nearby', e, requestId);
                return json({ error: 'temporarily_unavailable', requestId }, 503, cors);
            }
        }
        let raw;
        try {
            raw = await readLimitedJson(req);
        }
        catch (e) {
            return json({ error: e instanceof Error && e.message === 'payload_too_large' ? 'payload_too_large' : 'invalid_json' }, 400, cors);
        }
        const input = parseInput(raw, (deps.now ?? (() => new Date()))());
        if (!input)
            return json({ error: 'invalid_route_request' }, 400, cors);
        if ((0, time_1.dstTransitionDay)(input.serviceDate))
            return json({ error: 'dst_transition_not_supported_yet' }, 422, cors);
        // The walking provider is metered. Restrict paid itinerary queries across all
        // function instances, independent of the short-minute abuse limiter above.
        try {
            if (!await deps.consumeRateLimit('routing|paid-global|hourly', 12, 3600))
                return json({ error: 'pilot_hourly_budget_exhausted' }, 429, { ...cors, 'Retry-After': '3600' });
        }
        catch (e) {
            report('rate_limit', e, requestId);
            return json({ error: 'temporarily_unavailable', requestId }, 503, cors);
        }
        let stage = 'snapshot';
        try {
            const timetable = await deps.loadTimetable();
            stage = 'routing';
            const result = await (0, planner_1.planDoorToDoor)(timetable, deps.router, {
                serviceDate: input.serviceDate, departAfterSeconds: Number(input.departAt.slice(0, 2)) * 3600 + Number(input.departAt.slice(3, 5)) * 60,
                origin: input.origin, destination: input.destination, maxTransfers: input.maxTransfers,
                maxWalkingMeters: input.maxWalkingMeters, limit: input.limit, rankBy: input.prioritize,
                minTransferSeconds: 180, minBoardingSeconds: 90,
            }, {
                maxRequestCount: 12, maxOriginStops: 4, maxDestinationStops: 4, maxTransferPairs: 4,
                requestDeadlineMs: 20000, maxConcurrentWalkingRequests: 2, signal: req.signal,
                maxPedestrianDistanceMeters: input.maxWalkingMeters,
                modes: input.modes,
            });
            const journeys = rankItineraries(result.journeys, input.prioritize, input.limit).map((journey) => ({
                ...journey,
                boardingDetails: (0, boardingEvidence_1.journeyBoardingDetails)(journey, timetable.stops),
                connections: (0, connections_1.journeyConnections)(journey, timetable.stops),
            }));
            const adjacentDstDates = [-1, 1].map(offset => (0, time_1.offsetServiceDate)(input.serviceDate, offset)).filter(time_1.dstTransitionDay);
            const walkingSnapWarning = journeys.some(j => j.legs.some(l => l.type === 'walk' && l.endpointSnapMeters &&
                (l.endpointSnapMeters.from > 5 || l.endpointSnapMeters.to > 5)));
            const tightRailConnections = journeys.some(j => {
                const rides = j.legs.filter(l => l.type === 'ride');
                if (rides.length < 2 || !rides.some(l => l.mode === 'rail'))
                    return false;
                return (0, connections_1.journeyConnections)(j, timetable.stops).some(c => c.scheduledWindowSeconds <= 300);
            });
            return json({ serviceDate: input.serviceDate, feedVersion: result.feedVersion, prioritize: input.prioritize, modes: input.modes, journeys,
                walkingCoverage: result.coverage,
                coverageWarnings: [...(tightRailConnections ? [{ code: 'tight_rail_connection', note: 'Short scheduled rail connection. Boarding, platforms and transfer protection are not independently verified. Verify with Irish Rail.' }] : []),
                    ...(result.coverage?.candidateLimitReached ? [{ code: 'candidate_limit_reached', note: 'Search used a bounded set of stops or transfer candidates; further transport alternatives may exist.' }] : []),
                    ...(result.coverage && (result.coverage.skippedBudget > 0 || result.coverage.directSkippedBudget) ?
                        [{ code: 'walking_budget_truncated', note: 'Provider-call budget was exhausted. More route alternatives or walk-only routes may exist.' }] : []),
                    ...(adjacentDstDates.length ? [{ code: 'adjacent_dst_service_day_excluded', dates: adjacentDstDates }] : []),
                    ...(walkingSnapWarning ? [{ code: 'street_snap_gap_unrouted', note: 'Unrouted endpoint gaps are included using an UNVERIFIED straight-line walking-time estimate; do not draw those segments as walkable geometry.' }] : []),
                    ...(journeys.some(j => j.requiresSnapConfirmation) ? [{ code: 'snap_confirmation_required', note: 'One or more itineraries have a street snap exceeding 25 m. Display the adjusted road point and require the passenger to check accessibility before using the route.' }] : [])],
                realtime: false, status: 'scheduled_only',
                railRealtimeNote: input.modes.includes('rail') ? 'Rail itinerary times are GTFS schedules. Irish Rail reports limited real-time coverage on the Athlone–Westport/Ballina corridor. No train delay has been incorporated into this search.' : undefined,
                coverageNote: 'Regional GTFS subset: no result does not prove no public transport exists.',
                boardingNote: 'Official GTFS stop coordinates do not independently verify the side of the street or bay.',
                attribution: 'National Transport Authority (NTA) / GTFS timetable data',
            }, 200, cors);
        }
        catch (e) {
            report(stage, e, requestId);
            return json({ error: 'temporarily_unavailable', requestId }, 503, cors);
        }
    };
}
/** Development/testing only. Production MUST use a shared, atomic rate limiter. */
function createMemoryRateLimiter(now = () => Date.now()) {
    const buckets = new Map();
    return async (key, limit, seconds) => {
        const tick = now();
        if (buckets.size > 2000) {
            for (const [k, v] of buckets) {
                if (v.endsAt <= tick)
                    buckets.delete(k);
            }
        }
        const previous = buckets.get(key);
        const entry = !previous || previous.endsAt <= tick ? { count: 0, endsAt: tick + seconds * 1000 } : previous;
        entry.count++;
        buckets.set(key, entry);
        return entry.count <= limit;
    };
}
/** One expensive paginated GTFS load per TTL, with concurrent-call deduplication. */
function createSnapshotCache(loader, ttlMs = 300000, clock = () => Date.now()) {
    if (!Number.isInteger(ttlMs) || ttlMs < 1000 || ttlMs > 900000)
        throw new Error('invalid_cache_ttl');
    let current;
    let expires = 0;
    let pending;
    return async () => {
        if (current && clock() < expires)
            return current;
        if (!pending) {
            pending = loader().then(result => {
                if (!result.feedVersion || !result.stops.length || !result.trips.length)
                    throw new Error('invalid_snapshot');
                current = result;
                expires = clock() + ttlMs;
                return result;
            }).finally(() => { pending = undefined; });
        }
        return pending;
    };
}

  },
  './index': function(module, exports, require) {
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nearbyStops = void 0;
__exportStar(require("./types"), exports);
__exportStar(require("./time"), exports);
__exportStar(require("./boarding"), exports);
__exportStar(require("./engine"), exports);
__exportStar(require("./pedestrian"), exports);
__exportStar(require("./map"), exports);
__exportStar(require("./supabaseAdapter"), exports);
__exportStar(require("./gtfsSnapshot"), exports);
__exportStar(require("./boardingEvidence"), exports);
__exportStar(require("./connections"), exports);
__exportStar(require("./planner"), exports);
__exportStar(require("./httpApi"), exports);
__exportStar(require("./supabaseLimiter"), exports);
var nearbyStops_1 = require("./nearbyStops");
Object.defineProperty(exports, "nearbyStops", { enumerable: true, get: function () { return nearbyStops_1.nearbyStops; } });
__exportStar(require("./irishRail"), exports);

  },
  './map': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.journeyOverlay = journeyOverlay;
const boarding_1 = require("./boarding");
/** No invented bus shape: walking paths and boarding/alighting point markers only. */
function journeyOverlay(journey, stops) {
    const stopMap = new Map(stops.map(s => [s.id, s]));
    const points = (p) => p.map(x => [x.lon, x.lat]);
    const features = [];
    for (const [i, leg] of journey.legs.entries()) {
        if (leg.type === 'walk') {
            features.push({ type: 'Feature', properties: { kind: 'walk', purpose: leg.purpose, step: i }, geometry: { type: 'LineString', coordinates: points(leg.geometry) } });
        }
        else {
            for (const [type, id] of [['board', leg.boardStopId], ['alight', leg.alightStopId]]) {
                const stop = stopMap.get(id);
                if (!stop)
                    continue;
                features.push({ type: 'Feature', properties: { kind: type, stopId: id, stopCode: stop.code ?? null, tripId: leg.tripId, route: leg.routeName }, geometry: { type: 'Point', coordinates: [(0, boarding_1.routableStopCoordinate)(stop).lon, (0, boarding_1.routableStopCoordinate)(stop).lat] } });
            }
        }
    }
    return { type: 'FeatureCollection', features };
}

  },
  './nearbyStops': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nearbyStops = nearbyStops;
const boarding_1 = require("./boarding");
/** Uses only stops served by known GTFS trips; never calls this walking distance. */
function nearbyStops(timetable, origin, radiusMeters = 1200, limit = 8) {
    if (!Number.isFinite(origin.lat) || !Number.isFinite(origin.lon) ||
        !Number.isInteger(radiusMeters) || radiusMeters < 100 || radiusMeters > 2500 ||
        !Number.isInteger(limit) || limit < 1 || limit > 15)
        throw new Error('invalid_nearby_params');
    const trips = new Map(timetable.trips.map(t => [t.id, t]));
    const routes = new Map(timetable.routes.map(r => [r.id, r]));
    const used = new Map();
    for (const st of timetable.stopTimes) {
        const trip = trips.get(st.tripId);
        // Arrival-only and special-arrangement stops must NOT advertise a bus as boardable.
        if (!trip || !routes.has(trip.routeId) || st.departureSeconds === null ||
            !(st.pickupType == null || st.pickupType === 0))
            continue;
        const set = used.get(st.stopId) ?? new Set();
        set.add(trip.routeId);
        used.set(st.stopId, set);
    }
    return timetable.stops.flatMap(stop => {
        const routeIds = used.get(stop.id);
        if (!routeIds || !Number.isFinite(stop.lat) || !Number.isFinite(stop.lon))
            return [];
        const meters = (0, boarding_1.proximityMeters)(origin, stop);
        if (meters > radiusMeters)
            return [];
        const routeNames = [...routeIds].map(id => routes.get(id))
            .filter(route => route.mode === 'bus').map(route => route.name).sort((a, b) => a.localeCompare(b));
        if (!routeNames.length)
            return [];
        return [{ ...(0, boarding_1.boardingInstruction)(stop), distanceStraightLineMeters: Math.round(meters), routeNames }];
    }).sort((a, b) => a.distanceStraightLineMeters - b.distanceStraightLineMeters || a.stopId.localeCompare(b.stopId)).slice(0, limit);
}

  },
  './pedestrian': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StadiaWalkingRouter = void 0;
exports.decodePolyline6 = decodePolyline6;
exports.buildPedestrianPaths = buildPedestrianPaths;
const boarding_1 = require("./boarding");
/** No raw coordinates or exact household offsets are logged. */
function driftBucket(m) { return m <= 5 ? '0-5' : m <= 12 ? '5-12' : m <= 25 ? '12-25' : m <= 50 ? '25-50' : m <= 80 ? '50-80' : '>80'; }
/** Valhalla returns polyline6, NOT Google polyline5. */
function decodePolyline6(polyline) {
    const out = [];
    let index = 0, lat = 0, lon = 0;
    function read() {
        let shift = 0, result = 0;
        for (let steps = 0; steps < 10; steps++) {
            if (index >= polyline.length)
                throw new Error('invalid_polyline');
            const code = polyline.charCodeAt(index++) - 63;
            if (code < 0 || code > 63)
                throw new Error('invalid_polyline');
            result |= (code & 31) << shift;
            shift += 5;
            if (code < 32)
                return (result & 1) ? ~(result >> 1) : (result >> 1);
        }
        throw new Error('invalid_polyline');
    }
    while (index < polyline.length) {
        lat += read();
        lon += read();
        out.push({ lat: lat / 1e6, lon: lon / 1e6 });
    }
    return out;
}
/** Server-side adapter. Key stays on the backend. No API call occurs unless walk() is invoked. */
class StadiaWalkingRouter {
    apiKey;
    http;
    baseUrl;
    observeDrift;
    constructor(apiKey, http = fetch, baseUrl = 'https://api-eu.stadiamaps.com', observeDrift) {
        this.apiKey = apiKey;
        this.http = http;
        this.baseUrl = baseUrl;
        this.observeDrift = observeDrift;
        if (!apiKey)
            throw new Error('missing_stadia_api_key');
        if (!/^https:\/\/api(-eu)?\.stadiamaps\.com$/.test(baseUrl))
            throw new Error('unapproved_stadia_endpoint');
    }
    async walk(from, to, roles = { fromRole: 'stop', toRole: 'stop' }, signal) {
        if (!validCoordinate(from) || !validCoordinate(to))
            throw new Error('invalid_coordinates');
        const url = `${this.baseUrl}/route/v1`;
        const response = await this.http(url, {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Stadia-Auth ${this.apiKey}` },
            body: JSON.stringify({ locations: [from, to], costing: 'pedestrian', units: 'kilometers', shape_format: 'polyline6' }),
            signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(12000)]) : AbortSignal.timeout(12000),
        });
        if (response.status === 400 || response.status === 404)
            return null; // no routable path or invalid request, reject.
        if (!response.ok)
            throw new Error(`walking_api_failed_${response.status}`);
        const result = await response.json();
        const time = result.trip?.summary?.time;
        const distanceKm = result.trip?.summary?.length;
        const shape = result.trip?.legs?.[0]?.shape;
        if (typeof time !== 'number' || typeof distanceKm !== 'number' || typeof shape !== 'string')
            return null;
        const geometry = decodePolyline6(shape);
        if (geometry.length < 2 || !Number.isFinite(time) || time < 0 || !Number.isFinite(distanceKm) || distanceKm < 0)
            return null;
        const fromMeters = (0, boarding_1.proximityMeters)(geometry[0], from);
        const toMeters = (0, boarding_1.proximityMeters)(geometry[geometry.length - 1], to);
        const accepted = fromMeters <= (roles.fromRole === 'user' ? boarding_1.MAX_USER_ENDPOINT_DRIFT_METERS : boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS) &&
            toMeters <= (roles.toRole === 'user' ? boarding_1.MAX_USER_ENDPOINT_DRIFT_METERS : boarding_1.MAX_WALK_ENDPOINT_DRIFT_METERS);
        try {
            this.observeDrift?.({ endpoint: 'from', role: roles.fromRole, bucket: driftBucket(fromMeters), accepted });
            this.observeDrift?.({ endpoint: 'to', role: roles.toRole, bucket: driftBucket(toMeters), accepted });
        }
        catch { /* Observability must never affect routing. */ }
        if (!accepted)
            return null;
        // Valhalla's geometry starts at the snapped street point, not necessarily at the
        // user's real door or the GTFS stop. The missing connectors are NOT known walkable.
        // Count a straight-line estimate in both the walk budget and ETA, without drawing
        // a made-up segment or representing it as provider-confirmed route geometry.
        const connectorMeters = Math.ceil(fromMeters + toMeters);
        const connectorSeconds = Math.ceil(connectorMeters / 1.2);
        const requireConfirmation = (roles.fromRole === 'user' && fromMeters > boarding_1.USER_SNAP_CONFIRMATION_METERS) ||
            (roles.toRole === 'user' && toMeters > boarding_1.USER_SNAP_CONFIRMATION_METERS);
        const snappedUserEndpoints = {
            ...(roles.fromRole === 'user' && fromMeters > boarding_1.USER_SNAP_CONFIRMATION_METERS ? { from: geometry[0] } : {}),
            ...(roles.toRole === 'user' && toMeters > boarding_1.USER_SNAP_CONFIRMATION_METERS ? { to: geometry[geometry.length - 1] } : {})
        };
        return { durationSeconds: Math.ceil(time) + connectorSeconds,
            distanceMeters: Math.ceil(distanceKm * 1000) + connectorMeters, geometry,
            provider: 'stadia-valhalla-pedestrian', endpointSnapMeters: { from: Math.round(fromMeters), to: Math.round(toMeters) },
            unverifiedConnector: { meters: connectorMeters, estimatedSeconds: connectorSeconds, estimateOnly: true },
            ...(requireConfirmation ? { requiresSnapConfirmation: true, snappedUserEndpoints } : {}) };
    }
}
exports.StadiaWalkingRouter = StadiaWalkingRouter;
function validCoordinate(c) { return Number.isFinite(c.lat) && Number.isFinite(c.lon) && Math.abs(c.lat) <= 90 && Math.abs(c.lon) <= 180; }
/** Candidate discovery MAY use straight-line proximity, but every accepted leg requires a real walking-route response. */
async function buildPedestrianPaths(router, stops, origin, destination, opts = {}) {
    if (!validCoordinate(origin) || !validCoordinate(destination))
        throw new Error('invalid_coordinates');
    const originCap = Math.max(0, Math.min(opts.maxOriginStops ?? 8, 20));
    const destCap = Math.max(0, Math.min(opts.maxDestinationStops ?? 8, 20));
    const radius = Math.max(0, opts.candidateRadiusMeters ?? 1500);
    const maxTransfers = Math.max(0, Math.min(opts.maxTransferPairs ?? 32, 100));
    const budget = Math.max(0, Math.min(opts.maxRequestCount ?? 50, 200));
    const walkCap = Math.max(0, opts.maxPedestrianDistanceMeters ?? 2500);
    const deadline = Math.max(100, Math.min(opts.requestDeadlineMs ?? 20000, 60000));
    const concurrency = Math.max(1, Math.min(opts.maxConcurrentWalkingRequests ?? 2, 3));
    const timeoutSignal = AbortSignal.timeout(deadline);
    const signal = opts.signal ? AbortSignal.any([opts.signal, timeoutSignal]) : timeoutSignal;
    let used = 0;
    let skippedBudget = 0;
    let directSkippedBudget = false;
    const requestWalk = async (a, b, roles) => {
        if (signal.aborted)
            throw new Error('request_timeout');
        // Different GTFS stop IDs are not proof of the same physical boarding bay,
        // even if their provider coordinates happen to coincide exactly. Such a
        // transfer cannot be independently routed or verified by a zero-length path.
        if (roles.fromRole === 'stop' && roles.toRole === 'stop' && (0, boarding_1.proximityMeters)(a, b) < 0.01)
            return null;
        // Boarding directly at a known stop must not depend on providers accepting
        // zero-length requests (many routers reject identical endpoints).
        if ((0, boarding_1.proximityMeters)(a, b) < 0.01) {
            return { durationSeconds: 0, distanceMeters: 0, geometry: [a, b], provider: 'identical-endpoints-no-walk' };
        }
        if (used >= budget) {
            skippedBudget++;
            return null;
        }
        used++;
        // Promise.race also enforces the deadline for test/third-party routers
        // that ignore AbortSignal. Stadia itself receives the cancellation signal.
        let onAbort;
        const aborted = new Promise((_, reject) => {
            onAbort = () => reject(new Error('request_timeout'));
            signal.addEventListener('abort', onAbort, { once: true });
            if (signal.aborted)
                onAbort();
        });
        let r;
        try {
            r = await Promise.race([router.walk(a, b, roles, signal), aborted]);
        }
        finally {
            if (onAbort)
                signal.removeEventListener('abort', onAbort);
        }
        return r && r.distanceMeters <= walkCap ? r : null;
    };
    async function runBatch(items, fn) {
        let cursor = 0;
        let failed = false;
        await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, async () => {
            while (cursor < items.length && !failed) {
                const item = items[cursor++];
                try {
                    await fn(item);
                }
                catch (e) {
                    failed = true;
                    throw e;
                }
            }
        }));
    }
    const unique = [...new Map(stops.map(s => [s.id, s])).values()].filter(s => validCoordinate(s));
    const near = (p, max, preferred, direct) => {
        const priority = new Set(preferred ?? []);
        const directPriority = new Set(direct ?? []);
        return unique.map(s => ({ s, d: (0, boarding_1.proximityMeters)(p, s) }))
            .filter(x => x.d <= radius && x.d <= walkCap)
            .sort((a, b) => Number(b.d <= 5 && priority.has(b.s.id)) - Number(a.d <= 5 && priority.has(a.s.id)) ||
            Number(directPriority.has(b.s.id)) - Number(directPriority.has(a.s.id)) ||
            Number(priority.has(b.s.id)) - Number(priority.has(a.s.id)) || a.d - b.d || a.s.id.localeCompare(b.s.id))
            .slice(0, max).map(x => x.s);
    };
    const originCandidateCount = unique.filter(s => (0, boarding_1.proximityMeters)(origin, s) <= Math.min(radius, walkCap)).length;
    const destinationCandidateCount = unique.filter(s => (0, boarding_1.proximityMeters)(destination, s) <= Math.min(radius, walkCap)).length;
    const origins = near(origin, originCap, opts.preferredOriginStopIds, opts.directOriginStopIds), destinations = near(destination, destCap, opts.preferredDestinationStopIds, opts.directDestinationStopIds);
    const access = [], egress = [], transfers = [];
    let direct;
    const directCap = Math.max(0, Math.min(opts.maxDirectWalkMeters ?? 0, walkCap));
    // Schedule optional walking-only search AFTER transit access, egress and
    // transfer candidates. One direct route must not steal the last paid request.
    await runBatch(origins, async (s) => { const route = await requestWalk(origin, (0, boarding_1.routableStopCoordinate)(s), { fromRole: 'user', toRole: 'stop' }); if (route)
        access.push({ ...route, stopId: s.id }); });
    await runBatch(destinations, async (s) => { const route = await requestWalk((0, boarding_1.routableStopCoordinate)(s), destination, { fromRole: 'stop', toRole: 'user' }); if (route)
        egress.push({ ...route, stopId: s.id }); });
    // Reestablish stable candidate order regardless of provider response timing.
    const originOrder = new Map(origins.map((s, i) => [s.id, i]));
    const destOrder = new Map(destinations.map((s, i) => [s.id, i]));
    access.sort((a, b) => (originOrder.get(a.stopId) ?? 999) - (originOrder.get(b.stopId) ?? 999));
    egress.sort((a, b) => (destOrder.get(a.stopId) ?? 999) - (destOrder.get(b.stopId) ?? 999));
    // Discover short transfers deterministically, independent of the GTFS stop import order.
    // Spread candidates across geographic cells instead of exhausting the budget in one town.
    const known = new Map(unique.map(s => [s.id, s]));
    const pairs = [];
    const seen = new Set();
    const addPair = (a, b, priority = 'cross_route') => {
        if (a.id === b.id)
            return;
        if ((0, boarding_1.proximityMeters)((0, boarding_1.routableStopCoordinate)(a), (0, boarding_1.routableStopCoordinate)(b)) < 0.01)
            return;
        const k = JSON.stringify([a.id, b.id]);
        if (seen.has(k))
            return;
        seen.add(k);
        const distance = (0, boarding_1.proximityMeters)((0, boarding_1.routableStopCoordinate)(a), (0, boarding_1.routableStopCoordinate)(b));
        if (distance <= 650 && distance <= walkCap)
            pairs.push({ a, b, distance, priority });
    };
    if (opts.transferPairs) {
        for (const pair of opts.transferPairs) {
            const a = known.get(pair.fromStopId), b = known.get(pair.toStopId);
            if (a && b)
                addPair(a, b, pair.priority ?? 'cross_route');
        }
    }
    else {
        for (const a of unique)
            for (const b of unique)
                addPair(a, b);
    }
    const groups = new Map();
    for (const pair of pairs) {
        const key = [Math.floor(pair.a.lat * 50), Math.floor(pair.a.lon * 50)].join(':');
        const group = groups.get(key) ?? [];
        group.push(pair);
        groups.set(key, group);
    }
    const cells = [...groups.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    for (const [, group] of cells)
        group.sort((a, b) => a.distance - b.distance || a.a.id.localeCompare(b.a.id) || a.b.id.localeCompare(b.b.id));
    let attempted = 0;
    const transferJobs = [];
    // Tiered round-robin across geographic cells. An added nearby same-line
    // option must NOT crowd out an older cross-line route when the budget is 1.
    for (const tier of ['cross_route', 'same_route']) {
        const priorityCells = cells.map(([key, group]) => [key, group.filter(p => p.priority === tier)]);
        for (let depth = 0; attempted < maxTransfers && attempted < budget; depth++) {
            let found = false;
            for (const [, group] of priorityCells) {
                if (attempted >= maxTransfers || attempted >= budget)
                    break;
                const pair = group[depth];
                if (!pair)
                    continue;
                found = true;
                attempted++;
                transferJobs.push(pair);
            }
            if (!found)
                break;
        }
    }
    await runBatch(transferJobs, async (pair) => {
        // Directional road/crossing access. Never assume reverse direction is safe.
        const route = await requestWalk((0, boarding_1.routableStopCoordinate)(pair.a), (0, boarding_1.routableStopCoordinate)(pair.b), { fromRole: 'stop', toRole: 'stop' });
        if (route)
            transfers.push({ ...route, fromStopId: pair.a.id, toStopId: pair.b.id });
    });
    const transferOrder = new Map(transferJobs.map((pair, i) => [pair.a.id + '|' + pair.b.id, i]));
    transfers.sort((a, b) => (transferOrder.get(a.fromStopId + '|' + a.toStopId) ?? 999) - (transferOrder.get(b.fromStopId + '|' + b.toStopId) ?? 999));
    if (directCap > 0 && (0, boarding_1.proximityMeters)(origin, destination) <= directCap) {
        if (used >= budget)
            directSkippedBudget = true;
        else {
            const proposed = await requestWalk(origin, destination, { fromRole: 'user', toRole: 'user' });
            if (proposed && proposed.distanceMeters <= directCap)
                direct = proposed;
        }
    }
    return { origin, destination, access, egress, transfers, direct,
        coverage: { planned: origins.length + destinations.length + transferJobs.length +
                Number(directCap > 0 && (0, boarding_1.proximityMeters)(origin, destination) <= directCap),
            executed: used, skippedBudget, directSkippedBudget,
            candidateLimitReached: originCandidateCount > originCap || destinationCandidateCount > destCap || pairs.length > maxTransfers } };
}

  },
  './planner': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.planDoorToDoor = planDoorToDoor;
const engine_1 = require("./engine");
const pedestrian_1 = require("./pedestrian");
const time_1 = require("./time");
const boarding_1 = require("./boarding");
/** A conservative, GTFS-only preflight. If false, there is no boardable trip
 * within the planner's first-boarding window. Do not pay a street provider for
 * speculative transit access/egress in that case. Direct walking stays separate.
 * Treat all nearby service dates exactly as the engine does; do not reject an
 * overnight 25:00 trip merely because its service date was yesterday. */
function hasBoardableServiceInWindow(data, req) {
    if (!(0, time_1.validDate)(req.serviceDate))
        throw new Error('invalid_service_date');
    const serviceDates = [-1, 0, 1].map(delta => ({ delta, date: (0, time_1.offsetServiceDate)(req.serviceDate, delta) }))
        .filter(x => x.delta === 0 || !(0, time_1.dstTransitionDay)(x.date));
    const windowEnd = req.departAfterSeconds + 18 * 3600;
    const activeCache = new Map();
    const tripById = new Map(data.trips.map(t => [t.id, t]));
    for (const row of data.stopTimes) {
        if (row.departureSeconds == null || (row.pickupType != null && row.pickupType !== 0))
            continue;
        const trip = tripById.get(row.tripId);
        if (!trip)
            continue;
        for (const { delta, date } of serviceDates) {
            const dep = row.departureSeconds + delta * 86400;
            if (dep < req.departAfterSeconds || dep > windowEnd)
                continue;
            const key = trip.serviceId + '|' + date;
            let ok = activeCache.get(key);
            if (ok === undefined) {
                ok = (0, time_1.activeService)(trip.serviceId, date, data.calendars, data.exceptions);
                activeCache.set(key, ok);
            }
            if (ok)
                return true;
        }
    }
    return false;
}
/** Cheap, timetable-only candidate discovery, before paid pedestrian queries.
 * Directional bus topology helps prioritize a 5th useful stop over four closer
 * stops on irrelevant services. All actual transfers still require walking
 * routes from the provider, and departure times are validated by the engine. */
function candidateStopPreferences(data, req, maxRadius = 1500) {
    const originNear = data.stops.filter(s => (0, boarding_1.proximityMeters)(req.origin, s) <= maxRadius);
    const destNear = data.stops.filter(s => (0, boarding_1.proximityMeters)(req.destination, s) <= maxRadius);
    const originIds = new Set(originNear.map(s => s.id));
    const destinationIds = new Set(destNear.map(s => s.id));
    if (!originIds.size || !destinationIds.size)
        return { origin: [], destination: [], directOrigin: [], directDestination: [] };
    const stopMap = new Map(data.stops.map(s => [s.id, s]));
    const routeTripIds = new Set(data.trips.map(t => t.id));
    const timesByTrip = new Map();
    for (const row of data.stopTimes) {
        if (!routeTripIds.has(row.tripId))
            continue;
        const list = timesByTrip.get(row.tripId) ?? [];
        list.push(row);
        timesByTrip.set(row.tripId, list);
    }
    const weekdays = new Map();
    const serviceDays = [-1, 0, 1].map(delta => ({ delta, date: (0, time_1.offsetServiceDate)(req.serviceDate, delta) }))
        .filter(x => x.delta === 0 || !(0, time_1.dstTransitionDay)(x.date));
    const latest = req.departAfterSeconds + 18 * 3600;
    const graph = new Map();
    const directOrigin = new Set(), directDestination = new Set();
    const timeFeasibleOrigin = new Set();
    const walkingCap = Math.max(0, req.maxWalkingMeters ?? 2500);
    const minBoarding = Math.max(0, req.minBoardingSeconds ?? 60);
    // Optimistic walking speed (3 m/s) is deliberately FASTER than most people.
    // Reject only departures physically impossible even under this generous bound.
    const earliestFromOrigin = new Map(originNear.map(stop => [stop.id,
        req.departAfterSeconds + Math.ceil((0, boarding_1.proximityMeters)(req.origin, stop) / 3) + minBoarding]));
    for (const trip of data.trips) {
        const rows = (timesByTrip.get(trip.id) ?? []).sort((a, b) => a.sequence - b.sequence);
        if (rows.length < 2)
            continue;
        const activeDays = serviceDays.filter(({ delta, date }) => {
            const key = trip.serviceId + '|' + date;
            let ok = weekdays.get(key);
            if (ok === undefined) {
                ok = (0, time_1.activeService)(trip.serviceId, date, data.calendars, data.exceptions);
                weekdays.set(key, ok);
            }
            return ok && rows.some(r => r.departureSeconds != null && r.departureSeconds + delta * 86400 >= req.departAfterSeconds && r.departureSeconds + delta * 86400 <= latest);
        });
        if (!activeDays.length)
            continue;
        for (let i = 0; i < rows.length - 1; i++) {
            const from = rows[i];
            if (from.departureSeconds == null || !(from.pickupType == null || from.pickupType === 0) ||
                !activeDays.some(({ delta }) => from.departureSeconds + delta * 86400 >= req.departAfterSeconds && from.departureSeconds + delta * 86400 <= latest))
                continue;
            if (originIds.has(from.stopId) && (0, boarding_1.proximityMeters)(req.origin, stopMap.get(from.stopId)) <= walkingCap &&
                activeDays.some(({ delta }) => from.departureSeconds + delta * 86400 >= (earliestFromOrigin.get(from.stopId) ?? Infinity)))
                timeFeasibleOrigin.add(from.stopId);
            const next = graph.get(from.stopId) ?? new Set();
            for (let j = i + 1; j < rows.length; j++) {
                const to = rows[j];
                if (to.arrivalSeconds != null && (to.dropOffType == null || to.dropOffType === 0)) {
                    next.add(to.stopId);
                    if (destinationIds.has(to.stopId) && timeFeasibleOrigin.has(from.stopId)) {
                        directOrigin.add(from.stopId);
                        directDestination.add(to.stopId);
                    }
                }
            }
            graph.set(from.stopId, next);
        }
    }
    const reverse = new Map();
    for (const [a, ends] of graph)
        for (const b of ends) {
            const set = reverse.get(b) ?? new Set();
            set.add(a);
            reverse.set(b, set);
        }
    const allTransitStops = [...new Set([...graph.keys(), ...reverse.keys()])];
    const walkingNeighbourhood = new Map();
    function transferNeighbours(id) {
        let result = walkingNeighbourhood.get(id);
        if (result)
            return result;
        const base = stopMap.get(id);
        result = base ? allTransitStops.filter(other => other !== id && stopMap.has(other) && (0, boarding_1.proximityMeters)(base, stopMap.get(other)) <= 650) : [];
        walkingNeighbourhood.set(id, result);
        return result;
    }
    const step = (seed, edges, rounds) => {
        let frontier = new Set(seed), seen = new Set(seed);
        for (let round = 0; round < rounds; round++) {
            if (round > 0) {
                for (const id of [...frontier])
                    for (const neighbour of transferNeighbours(id))
                        frontier.add(neighbour);
            }
            const next = new Set();
            for (const id of frontier)
                for (const connected of edges.get(id) ?? [])
                    next.add(connected);
            for (const id of next)
                seen.add(id);
            frontier = next;
        }
        return seen;
    };
    const rounds = Math.max(1, Math.min(3, (req.maxTransfers ?? 1) + 1));
    // To reach a destination follow the reverse graph; to come from an origin
    // follow the forward graph. Both are purely priority hints.
    const toDestination = step(destinationIds, reverse, rounds);
    const fromOrigin = step(originIds, graph, rounds);
    return { origin: originNear.filter(s => toDestination.has(s.id) && timeFeasibleOrigin.has(s.id)).map(s => s.id),
        destination: destNear.filter(s => fromOrigin.has(s.id)).map(s => s.id),
        directOrigin: [...directOrigin], directDestination: [...directDestination] };
}
/**
 * A controlled, server-side integration seam. No provider key or database secret
 * is ever serialized into the response. Missing pedestrian routes mean no itinerary.
 */
async function planDoorToDoor(timetable, router, req, opts = {}) {
    // Preserve bus-only legacy behavior unless rail was explicitly requested.
    // Never infer rail access from the GTFS feed merely containing trains.
    const modes = new Set(opts.modes ?? (opts.includeRail ? ['bus', 'rail'] : ['bus']));
    if (!modes.size || [...modes].some(m => m !== 'bus' && m !== 'rail'))
        throw new Error('invalid_modes');
    const allowedRoutes = new Set(timetable.routes.filter(r => modes.has(r.mode)).map(r => r.id));
    const eligibleTrips = timetable.trips.filter(t => allowedRoutes.has(t.routeId));
    const eligibleTripIds = new Set(eligibleTrips.map(t => t.id));
    const times = timetable.stopTimes.filter(st => eligibleTripIds.has(st.tripId));
    const usedStopIds = new Set(times.map(st => st.stopId));
    const routes = timetable.routes.filter(r => allowedRoutes.has(r.id));
    const stops = timetable.stops.filter(s => usedStopIds.has(s.id));
    const data = { ...timetable, stops, routes, trips: eligibleTrips, stopTimes: times };
    // Distinct VEHICLES (GTFS trip IDs), not necessarily distinct routes: e.g.
    // transferring between two 420 services must be possible when schedule and
    // provider-verified street connections allow it. Reboarding the SAME trip
    // remains forbidden in engine.ts.
    const routeForTrip = new Map(eligibleTrips.map(t => [t.id, t.routeId]));
    const boardingTrips = new Map(), alightingTrips = new Map();
    for (const st of times) {
        if (st.departureSeconds != null && (st.pickupType == null || st.pickupType === 0)) {
            const s = boardingTrips.get(st.stopId) ?? new Set();
            s.add(st.tripId);
            boardingTrips.set(st.stopId, s);
        }
        if (st.arrivalSeconds != null && (st.dropOffType == null || st.dropOffType === 0)) {
            const s = alightingTrips.get(st.stopId) ?? new Set();
            s.add(st.tripId);
            alightingTrips.set(st.stopId, s);
        }
    }
    const stopMap = new Map(stops.map(s => [s.id, s]));
    const transferPairs = [];
    const ids = [...stopMap.keys()];
    const transitAvailable = hasBoardableServiceInWindow(data, req);
    if (transitAvailable && (req.maxTransfers ?? 1) > 0) {
        for (const a of ids) {
            const from = alightingTrips.get(a);
            if (!from)
                continue;
            for (const b of ids) {
                if (a === b)
                    continue;
                const to = boardingTrips.get(b);
                if (!to)
                    continue;
                // pedestrian.ts already applies this exact geometric bound. Apply it
                // before creating potentially thousands of extra same-line pairs;
                // this is a cost-only filter, never evidence of walkability.
                const distance = (0, boarding_1.proximityMeters)((0, boarding_1.routableStopCoordinate)(stopMap.get(a)), (0, boarding_1.routableStopCoordinate)(stopMap.get(b)));
                if (distance < 0.01 || distance > 650 || distance > Math.max(0, req.maxWalkingMeters ?? 2500))
                    continue;
                if (![...from].some(fr => [...to].some(tr => fr !== tr)))
                    continue;
                // Keep legacy cross-route connections ahead of newly supported
                // same-line transfers when the paid walking budget is very small.
                const cross = [...from].some(fr => [...to].some(tr => fr !== tr && routeForTrip.get(fr) !== routeForTrip.get(tr)));
                transferPairs.push({ fromStopId: a, toStopId: b, priority: cross ? 'cross_route' : 'same_route' });
            }
        }
    }
    // Bound provider billing per user search. Expand only after measuring real Mayo results.
    const budget = Math.max(0, Math.min(opts.maxRequestCount ?? 24, 200));
    // A user's walking budget is an upper bound on any access/egress segment.
    // A smaller, hard-coded discovery radius must never silently shrink it.
    const walkCap = Math.max(0, req.maxWalkingMeters ?? 2500);
    const candidateRadius = opts.candidateRadiusMeters ?? walkCap;
    const priority = transitAvailable ? candidateStopPreferences(data, req, candidateRadius) :
        { origin: [], destination: [], directOrigin: [], directDestination: [] };
    const paths = await (0, pedestrian_1.buildPedestrianPaths)(router, transitAvailable ? stops : [], req.origin, req.destination, {
        ...opts, maxRequestCount: budget, candidateRadiusMeters: candidateRadius,
        maxPedestrianDistanceMeters: Math.min(opts.maxPedestrianDistanceMeters ?? walkCap, walkCap), transferPairs,
        preferredOriginStopIds: priority.origin, preferredDestinationStopIds: priority.destination,
        directOriginStopIds: priority.directOrigin, directDestinationStopIds: priority.directDestination,
        maxDirectWalkMeters: Math.min(opts.maxDirectWalkMeters ?? 1400, req.maxWalkingMeters ?? 2500),
        maxOriginStops: opts.maxOriginStops ?? 5,
        maxDestinationStops: opts.maxDestinationStops ?? 5,
        maxTransferPairs: (req.maxTransfers ?? 1) > 0 ? (opts.maxTransferPairs ?? 12) : 0,
    });
    const journeys = (0, engine_1.planJourneys)(data, paths, req);
    return { journeys, walkingRequestsBudget: budget, feedVersion: data.feedVersion, coverage: paths.coverage };
}

  },
  './supabaseAdapter': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromSupabaseTables = fromSupabaseTables;
function str(v) { return v == null ? '' : String(v); }
function num(v) { return v === null || v === undefined || v === '' ? null : Number.isFinite(Number(v)) ? Number(v) : null; }
function normalDate(v) { return str(v).slice(0, 10); }
;
/** Call only with rows loaded for ONE active feed version by a trusted server-side repository. */
function fromSupabaseTables(t) {
    if (!t.feedVersion)
        throw new Error('missing_gtfs_version');
    for (const [table, rows] of Object.entries({ stops: t.stops, routes: t.routes, trips: t.trips, stopTimes: t.stopTimes, calendars: t.calendars, calendarDates: t.calendarDates })) {
        if (!Array.isArray(rows) || rows.some(row => row.version !== t.feedVersion))
            throw new Error(`mixed_gtfs_version_${table}`);
    }
    const stops = t.stops.filter(s => num(s.stop_lat) !== null && num(s.stop_lon) !== null).map(s => ({ id: str(s.stop_id), name: str(s.stop_name), lat: num(s.stop_lat), lon: num(s.stop_lon), code: str(s.stop_code) || null, description: str(s.stop_desc) || null, boarding: { confidence: 'official_unverified' } }));
    const routes = t.routes.map(r => ({ id: str(r.route_id), name: str(r.route_short_name) || str(r.route_long_name) || str(r.route_id), mode: num(r.route_type) === 2 ? 'rail' : 'bus' }));
    const trips = t.trips.map(x => ({ id: str(x.trip_id), routeId: str(x.route_id), serviceId: str(x.service_id), headsign: str(x.trip_headsign) || null }));
    const stopTimes = t.stopTimes.map(s => ({ tripId: str(s.trip_id), stopId: str(s.stop_id), sequence: num(s.stop_sequence) ?? -1, arrivalSeconds: num(s.arrival_seconds), departureSeconds: num(s.departure_seconds), pickupType: num(s.pickup_type), dropOffType: num(s.drop_off_type) }));
    const calendars = t.calendars.map(c => ({ serviceId: str(c.service_id), startDate: normalDate(c.start_date), endDate: normalDate(c.end_date), weekdays: [c.sunday === true, c.monday === true, c.tuesday === true, c.wednesday === true, c.thursday === true, c.friday === true, c.saturday === true] }));
    const exceptions = t.calendarDates.map(c => ({ serviceId: str(c.service_id), date: normalDate(c.service_date), type: num(c.exception_type) === 1 ? 1 : 2 }));
    return { feedVersion: t.feedVersion, timezone: 'Europe/Dublin', stops, routes, trips, stopTimes, calendars, exceptions };
}

  },
  './supabaseLimiter': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSupabaseRateLimiter = createSupabaseRateLimiter;
function createSupabaseRateLimiter(options) {
    const { supabaseUrl, privateKey } = options;
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(supabaseUrl) || !privateKey || /\s/.test(privateKey)) {
        throw new Error('invalid_rate_limiter_configuration');
    }
    const fetcher = options.fetcher ?? fetch;
    const timeout = options.timeoutMs ?? 6000;
    if (!Number.isInteger(timeout) || timeout < 100 || timeout > 20000)
        throw new Error('invalid_rate_limiter_timeout');
    const endpoint = supabaseUrl.replace(/\/$/, '') + '/rest/v1/rpc/consume_transport_api_rate_limit';
    const headers = { 'Content-Type': 'application/json', apikey: privateKey };
    if (privateKey.startsWith('eyJ'))
        headers.Authorization = `Bearer ${privateKey}`;
    return async (bucket, limit, windowSeconds) => {
        if (!bucket || bucket.length > 500 || !Number.isInteger(limit) || limit < 1 || limit > 1000 || ![60, 3600].includes(windowSeconds)) {
            throw new Error('invalid_rate_limit_args');
        }
        // Do not store literal remote IP in the database rate-limit key.
        const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('ballina-routing-v1|' + bucket));
        const key = Array.from(new Uint8Array(hash)).map(x => x.toString(16).padStart(2, '0')).join('');
        const response = await fetcher(endpoint, {
            method: 'POST', headers,
            body: JSON.stringify({ p_key: key, p_limit: limit, p_window_seconds: windowSeconds }),
            signal: AbortSignal.timeout(timeout),
        });
        if (!response.ok)
            throw new Error('rate_limiter_unavailable');
        const result = await response.json();
        if (!Array.isArray(result) || result.length !== 1 || !result[0] || typeof result[0] !== 'object' || typeof result[0].allowed !== 'boolean') {
            throw new Error('invalid_rate_limiter_response');
        }
        return result[0].allowed;
    };
}

  },
  './time': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validDate = validDate;
exports.activeService = activeService;
exports.offsetServiceDate = offsetServiceDate;
exports.parseGtfsTime = parseGtfsTime;
exports.displayServiceTime = displayServiceTime;
exports.dstTransitionDay = dstTransitionDay;
const dateRx = /^\d{4}-\d{2}-\d{2}$/;
function validDate(value) {
    if (!dateRx.test(value))
        return false;
    const dt = new Date(value + 'T00:00:00Z');
    return !Number.isNaN(dt.getTime()) && dt.toISOString().slice(0, 10) === value;
}
function activeService(serviceId, date, calendars, exceptions) {
    if (!validDate(date))
        throw new Error('invalid_service_date');
    const exception = exceptions.find(x => x.serviceId === serviceId && x.date === date);
    if (exception)
        return exception.type === 1;
    const rule = calendars.find(x => x.serviceId === serviceId);
    if (!rule || date < rule.startDate || date > rule.endDate)
        return false;
    return rule.weekdays[new Date(date + 'T00:00:00Z').getUTCDay()] === true;
}
/** Calendar arithmetic for GTFS service dates; UTC is used ONLY for date math. */
function offsetServiceDate(day, offset) {
    if (!validDate(day) || !Number.isInteger(offset) || Math.abs(offset) > 2)
        throw new Error('invalid_service_date_offset');
    const d = new Date(day + 'T00:00:00Z');
    d.setUTCDate(d.getUTCDate() + offset);
    return d.toISOString().slice(0, 10);
}
function parseGtfsTime(time) {
    const match = /^(\d{1,3}):(\d{2}):(\d{2})$/.exec(time);
    if (!match)
        throw new Error('invalid_gtfs_time');
    const h = Number(match[1]), m = Number(match[2]), s = Number(match[3]);
    if (h > 99 || m > 59 || s > 59)
        throw new Error('invalid_gtfs_time');
    return h * 3600 + m * 60 + s;
}
function displayServiceTime(seconds) {
    if (!Number.isFinite(seconds) || seconds < 0)
        throw new Error('invalid_service_seconds');
    const whole = Math.floor(seconds);
    const d = Math.floor(whole / 86400);
    const h = Math.floor(whole % 86400 / 3600);
    const m = Math.floor(whole % 3600 / 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}${d ? ` (+${d}d)` : ''}`;
}
/** Used only to WARN on transition dates: this prototype never claims timezone-safe UTC ETAs on DST boundaries. */
function dstTransitionDay(date) {
    if (!validDate(date))
        throw new Error('invalid_service_date');
    const [yy, mm, dd] = date.split('-').map(Number);
    if (mm !== 3 && mm !== 10)
        return false;
    const dayOfWeek = new Date(Date.UTC(yy, mm - 1, dd)).getUTCDay();
    const daysInMonth = new Date(Date.UTC(yy, mm, 0)).getUTCDate();
    return dayOfWeek === 0 && dd + 7 > daysInMonth;
}

  },
  './types': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

  },
  './irishRail': function(module, exports, require) {
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IRISH_RAIL_COVERAGE_WARNING = void 0;
exports.parseIrishRailStationXml = parseIrishRailStationXml;
exports.createIrishRailStationClient = createIrishRailStationClient;
exports.IRISH_RAIL_COVERAGE_WARNING = 'The Irish Rail API may return scheduled rather than observed times on the Athlone–Westport/Ballina line. Train services are not automatically matched to GTFS trip IDs.';
const ENDPOINT = 'https://api.irishrail.ie/realtime/realtime.asmx/getStationDataByNameXML';
const KNOWN_MAX_XML_BYTES = 256_000;
function decode(value) {
    // Reject XML entities not in the five predefined entities, preventing fake
    // nested expansion and mangled/untrusted passenger-facing text.
    // Check the RAW XML, not the decoded result: `&amp;Belfast` is valid XML
    // text denoting `&Belfast`, and must not be rejected after decoding.
    if (/&(?!(?:amp|lt|gt|quot|apos);)/.test(value))
        throw new Error('invalid_rail_xml_entity');
    const safe = value.replace(/&(amp|lt|gt|quot|apos);/g, (_whole, key) => ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" })[key] ?? '');
    return safe.trim().slice(0, 160);
}
function field(raw, key) {
    const pattern = new RegExp(`<(?:(?:[A-Za-z_][\\w.-]*):)?${key}\\s*>([\\s\\S]*?)<\\/(?:(?:[A-Za-z_][\\w.-]*):)?${key}\\s*>`, 'i');
    const found = pattern.exec(raw)?.[1];
    if (found === undefined || /<[^>]+>/.test(found))
        return null;
    const val = decode(found);
    return val || null;
}
function intField(raw, key) {
    const value = field(raw, key);
    if (value == null || !/^\d{1,4}$/.test(value))
        return null;
    const n = Number(value);
    return Number.isSafeInteger(n) && n <= 1440 ? n : null;
}
function clockField(raw, key) {
    const s = field(raw, key);
    return s && /^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(s) ? s : null;
}
/** Verify the structural subset returned by Irish Rail before extracting records.
 * XML fields are leaves; only objStationData can be a direct child of the root.
 * This rejects malformed XML and ghost services hidden in unexpected wrappers.
 * It is intentionally NOT a general-purpose XML parser (no CDATA or DTDs). */
function validateStationBody(inner) {
    const stack = [];
    const tags = /<([^<>]+)>/g;
    let position = 0;
    function verifyText(text) {
        if (text.includes('<'))
            throw new Error('invalid_rail_xml_response');
        if (stack.length < 2) {
            if (text.trim())
                throw new Error('invalid_rail_xml_response');
        }
        else
            decode(text); // validate predefined entities even in unknown leaf fields
    }
    for (let match; (match = tags.exec(inner)) !== null;) {
        verifyText(inner.slice(position, match.index));
        const source = (match[1] ?? '').trim();
        const closing = /^\/([A-Za-z_][\w.-]*(?::[A-Za-z_][\w.-]*)?)\s*$/.exec(source);
        if (closing) {
            if (stack.pop() !== closing[1])
                throw new Error('invalid_rail_xml_response');
        }
        else {
            const opening = /^([A-Za-z_][\w.-]*(?::[A-Za-z_][\w.-]*)?)(?:\s+[^<>]*?)?\s*(\/)?$/.exec(source);
            if (!opening)
                throw new Error('invalid_rail_xml_response');
            const localName = opening[1].split(':').pop();
            if (stack.length === 0 ? localName !== 'objStationData' : stack.length !== 1 || localName === 'objStationData')
                throw new Error('invalid_rail_xml_response');
            if (!opening[2])
                stack.push(opening[1]);
            else if (stack.length === 0)
                throw new Error('invalid_rail_xml_response');
        }
        position = tags.lastIndex;
    }
    verifyText(inner.slice(position));
    if (stack.length)
        throw new Error('invalid_rail_xml_response');
}
/** Strict parsing of this one provider's known response object, not a general-purpose XML parser. */
function parseIrishRailStationXml(xml, station, fetchedAt) {
    if (xml.length > KNOWN_MAX_XML_BYTES || /<!\s*(?:DOCTYPE|ENTITY)/i.test(xml))
        throw new Error('invalid_rail_xml_response');
    // Official SOAP XML can contain comments. Never parse a train hidden inside one.
    const noComments = xml.replace(/<!--[\s\S]*?-->/g, '').replace(/^\uFEFF/, '').trim();
    if (noComments.includes('<!--') || noComments.includes('-->') || /<!\[CDATA\[/i.test(noComments))
        throw new Error('invalid_rail_xml_response');
    const root = /^(?:<\?xml\s[^<>]*\?>\s*)?<(?:[A-Za-z_][\w.-]*:)?ArrayOfObjStationData(?=[\s/>])[^<>]*?(\/?)>/.exec(noComments);
    if (!root)
        throw new Error('invalid_rail_xml_response');
    if (root[1] === '/') {
        if (noComments.slice(root[0].length).trim())
            throw new Error('invalid_rail_xml_response');
    }
    else {
        const close = /<\/(?:[A-Za-z_][\w.-]*:)?ArrayOfObjStationData\s*>\s*$/i.exec(noComments);
        if (!close)
            throw new Error('invalid_rail_xml_response');
        validateStationBody(noComments.slice(root[0].length, close.index));
    }
    const declared = (noComments.match(/<(?:[A-Za-z_][\w.-]*:)?objStationData(?=[\s/>])/gi) ?? []).length;
    const closed = (noComments.match(/<\/(?:[A-Za-z_][\w.-]*:)?objStationData\s*>/gi) ?? []).length;
    if (declared !== closed)
        throw new Error('invalid_rail_xml_response');
    const services = [];
    const re = /<(?:\w+:)?objStationData(?:\s+[^<>]*?)?\s*>([\s\S]*?)<\/(?:\w+:)?objStationData\s*>/gi;
    for (let match; (match = re.exec(noComments)) !== null;) {
        if (services.length >= 120)
            throw new Error('rail_station_board_too_large');
        const data = match[1] ?? '';
        const trainCode = field(data, 'Traincode') ?? '';
        const stationName = field(data, 'Stationfullname') ?? '';
        if (!/^[A-Za-z0-9]{1,12}$/.test(trainCode) || !stationName)
            throw new Error('invalid_rail_train_record');
        services.push({ trainCode, stationName, origin: field(data, 'Origin') ?? '', destination: field(data, 'Destination') ?? '',
            trainDate: field(data, 'Traindate'), scheduledArrival: clockField(data, 'Scharrival'), scheduledDeparture: clockField(data, 'Schdepart'),
            expectedArrival: clockField(data, 'Exparrival'), expectedDeparture: clockField(data, 'Expdepart'),
            lateMinutes: intField(data, 'Late'), dueInMinutes: intField(data, 'Duein'), status: field(data, 'Status'), lastLocation: field(data, 'Lastlocation') });
    }
    if (services.length !== declared)
        throw new Error('invalid_rail_xml_response');
    return { station, source: 'irish_rail_station_api', fetchedAt, dataQuality: 'official_api_may_show_schedule_only', matchedToGtfsTrips: false, services };
}
function createIrishRailStationClient(options = {}) {
    const fetcher = options.fetcher ?? fetch, now = options.now ?? (() => new Date());
    const timeoutMs = Math.max(100, Math.min(10000, options.timeoutMs ?? 5000));
    const cacheMs = Math.max(1000, Math.min(120000, options.cacheMs ?? 45000));
    const cache = new Map();
    // Deduplicate requests before the station response has entered the TTL cache.
    const pending = new Map();
    async function readBounded(response) {
        const declared = response.headers.get('content-length');
        if (declared && Number(declared) > KNOWN_MAX_XML_BYTES)
            throw new Error('rail_upstream_response_too_large');
        if (!response.body)
            throw new Error('rail_upstream_empty_body');
        const reader = response.body.getReader(), chunks = [];
        let total = 0;
        try {
            for (;;) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                total += value.byteLength;
                if (total > KNOWN_MAX_XML_BYTES) {
                    await reader.cancel().catch(() => undefined);
                    throw new Error('rail_upstream_response_too_large');
                }
                chunks.push(value);
            }
        }
        finally {
            reader.releaseLock();
        }
        const raw = new Uint8Array(total);
        let position = 0;
        for (const chunk of chunks) {
            raw.set(chunk, position);
            position += chunk.length;
        }
        return new TextDecoder('utf-8', { fatal: true }).decode(raw);
    }
    return async function getStationBoard(station) {
        if (!/^[A-Za-z][A-Za-z '-]{1,58}$/.test(station))
            throw new Error('invalid_rail_station');
        const key = station.toLowerCase();
        const existing = cache.get(key);
        if (existing && existing.expires > now().getTime())
            return existing.board;
        const underway = pending.get(key);
        if (underway)
            return underway;
        const run = (async () => {
            const controller = new AbortController();
            let timedOut = false;
            let timeout;
            const work = (async () => {
                const response = await fetcher(`${ENDPOINT}?StationDesc=${encodeURIComponent(station)}`, {
                    method: 'GET', signal: controller.signal, headers: { Accept: 'application/xml,text/xml' }
                });
                if (!response.ok)
                    throw new Error('irish_rail_upstream_unavailable');
                const body = await readBounded(response);
                // A mock or nonstandard fetcher may ignore AbortSignal. No late result
                // may poison the station cache after the timeout was reported.
                if (timedOut)
                    throw new Error('irish_rail_timeout');
                const board = parseIrishRailStationXml(body, station, now().toISOString());
                if (cache.size > 100)
                    cache.clear();
                cache.set(key, { expires: now().getTime() + cacheMs, board });
                return board;
            })();
            const deadline = new Promise((_, reject) => {
                timeout = setTimeout(() => {
                    timedOut = true;
                    controller.abort();
                    reject(new Error('irish_rail_timeout'));
                }, timeoutMs);
            });
            try {
                return await Promise.race([work, deadline]);
            }
            finally {
                if (timeout)
                    clearTimeout(timeout);
            }
        })();
        pending.set(key, run);
        try {
            return await run;
        }
        finally {
            if (pending.get(key) === run)
                pending.delete(key);
        }
    };
}

  },
};
const __ballinaCache = {};
function __ballinaRequire(moduleId) {
  const cached = __ballinaCache[moduleId];
  if (cached) return cached.exports;
  const factory = __ballinaModules[moduleId];
  if (!factory) throw new Error('unknown_module');
  const module = {exports: {}};
  __ballinaCache[moduleId] = module;
  factory(module, module.exports, __ballinaRequire);
  return module.exports;
}
const {createRoutingApi,createSnapshotCache}=__ballinaRequire('./httpApi');
const {loadActiveGtfsSnapshot}=__ballinaRequire('./gtfsSnapshot');
const {StadiaWalkingRouter}=__ballinaRequire('./pedestrian');
const {createSupabaseRateLimiter}=__ballinaRequire('./supabaseLimiter');

const {createIrishRailStationClient}=__ballinaRequire('./irishRail');
// Private preview: dedicated credential, independent from the project database secret.
// This remains server-to-server only. Never embed the preview token in a browser.
function readNamedKey(jsonEnv:string, envNames:string[]):string {
  const raw=Deno.env.get(jsonEnv);
  if(raw){try{const named=JSON.parse(raw);if(named&&typeof named.default==='string')return named.default;}catch{ /* fallback */ }}
  for(const name of envNames){const key=Deno.env.get(name);if(key)return key;}
  return '';
}
const supabaseUrl=Deno.env.get('SUPABASE_URL')??'';
const secret=readNamedKey('SUPABASE_SECRET_KEYS',['SUPABASE_SECRET_KEY','SUPABASE_SERVICE_ROLE_KEY','SB_SERVICE_ROLE_KEY']);
const publishable=readNamedKey('SUPABASE_PUBLISHABLE_KEYS',['SUPABASE_PUBLISHABLE_KEY','SUPABASE_ANON_KEY']);
const stadiaKey=Deno.env.get('STADIA_API_KEY')??'';
const previewToken=Deno.env.get('BALLINA_ROUTING_PREVIEW_TOKEN')??'';
const railRealtimeEnabled=Deno.env.get('BALLINA_RAIL_REALTIME_ENABLED')==='true';
const tokenReady=previewToken.length>=32 && previewToken!==secret && previewToken!==publishable;
/** Fixed-length digest comparison; missing or unconfigured token fails closed. */
async function tokenMatches(presented:string|null):Promise<boolean>{
  if(!tokenReady||!presented||presented.length>256)return false;
  const digest=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
  const a=await digest(previewToken),b=await digest(presented);
  let difference=0;for(let i=0;i<a.length;i++)difference|=a[i]!^b[i]!;
  return difference===0;
}
// Rail station data is read-only and must not depend on a paid walking API key.
// Route planning still fails closed unless a walking provider is configured.
const dataReady=Boolean(supabaseUrl&&secret&&publishable&&tokenReady);
const ready=Boolean(dataReady&&stadiaKey);
const limiter=dataReady?createSupabaseRateLimiter({supabaseUrl,privateKey:secret}):null;
const routeHandler=dataReady?createRoutingApi({
  loadTimetable:createSnapshotCache(()=>loadActiveGtfsSnapshot({supabaseUrl,privateKey:secret}),300_000),
  router:stadiaKey?new StadiaWalkingRouter(stadiaKey,fetch,'https://api-eu.stadiamaps.com',
    sample=>console.info(JSON.stringify({service:'ballina-routing-preview',kind:'endpoint_drift',...sample}))):
    {walk:async()=>null}, // Rail-only read endpoints never invoke a paid router.
  clientIdentity:(_req)=>'private-preview',
  consumeRateLimit:limiter!,
  getRailStationBoard:railRealtimeEnabled?createIrishRailStationClient({timeoutMs:5000,cacheMs:45000}):undefined,
  allowedOrigins:[],
  reportError:event=>console.error(JSON.stringify({service:'ballina-routing-preview',kind:'routing_failure',...event})),
}):null;
function answer(value:unknown,status=200):Response {
  return Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
Deno.serve(async(req:Request)=>{
  const path=new URL(req.url).pathname;
  const isHealth=path.endsWith('/health');
  const isJourney=path.endsWith('/v1/journeys');
  const isNearby=path.endsWith('/v1/nearby-stops');
  const isRailBoard=path.endsWith('/v1/rail/station-board');
  const isRailStations=path.endsWith('/v1/rail/stations');
  if(isHealth&&req.method==='GET'){
    if(!publishable||req.headers.get('apikey')!==publishable)return answer({error:'unauthorized'},401);
    return answer({service:'ballina-routing-preview',status:ready?'ready_for_private_testing':dataReady?'rail_station_only':'missing_configuration',stadia_configured:Boolean(stadiaKey),public_planning_enabled:false});
  }
  if(!isJourney&&!isNearby&&!isRailBoard&&!isRailStations)return answer({error:'not_found'},404);
  if(isJourney?req.method!=='POST':req.method!=='GET')return answer({error:'method_not_allowed'},405);
  if(!tokenReady)return answer({error:'preview_not_configured'},503);
  if(!await tokenMatches(req.headers.get('x-ballina-preview-token')))return answer({error:'unauthorized'},401);
  if(!routeHandler)return answer({error:'preview_unavailable'},503);
  // No paid walking provider? Keep journeys sealed, even at identical endpoints.
  if(isJourney&&!ready)return answer({error:'walking_provider_unavailable'},503);
  // Normalize the public Edge prefix, but retain the already-authorized endpoint.
  // In particular, rail station handlers must never be silently rewritten to
  // nearby-stops after the private token was verified.
  const parsed=new URL(req.url);
  parsed.pathname=isJourney?'/v1/journeys':isNearby?'/v1/nearby-stops':
    isRailBoard?'/v1/rail/station-board':'/v1/rail/stations';
  if(isJourney)parsed.search='';
  // Cloning the incoming request retains its streaming-body protocol semantics.
  return routeHandler(new Request(parsed,req));
});
